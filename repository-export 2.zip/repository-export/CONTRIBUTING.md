# Contributing to VibeVerse

Thank you for your interest in contributing to VibeVerse! This document provides guidelines and information for contributors.

## 🚀 Getting Started

### Prerequisites
- Node.js 18+
- PostgreSQL database
- Git
- PayPal Developer Account (for testing payment features)

### Development Setup
1. Fork the repository
2. Clone your fork: `git clone https://github.com/your-username/vibeverse.git`
3. Install dependencies: `npm install`
4. Copy `.env.example` to `.env` and configure
5. Run database migrations: `npm run db:migrate`
6. Start development server: `npm run dev`

## 🎯 How to Contribute

### Reporting Issues
- Use GitHub Issues to report bugs
- Include detailed description, steps to reproduce, and environment info
- Add appropriate labels (bug, enhancement, documentation, etc.)

### Submitting Changes
1. Create a feature branch: `git checkout -b feature/amazing-feature`
2. Make your changes following our coding standards
3. Test your changes thoroughly
4. Commit with clear messages: `git commit -m 'Add amazing feature'`
5. Push to your fork: `git push origin feature/amazing-feature`
6. Open a Pull Request

## 📋 Coding Standards

### TypeScript Guidelines
- Use TypeScript for all new code
- Define proper interfaces and types
- Avoid `any` types - use proper typing
- Use Zod schemas for runtime validation

### Code Style
- Use Prettier for formatting (configured in project)
- Follow ESLint rules
- Use meaningful variable and function names
- Write self-documenting code with comments where needed

### Component Structure
```typescript
// React components should follow this structure:
import { useState } from "react";
import { Button } from "@/components/ui/button";

interface ComponentProps {
  prop1: string;
  prop2?: number;
}

export function Component({ prop1, prop2 = 0 }: ComponentProps) {
  const [state, setState] = useState<string>("");
  
  return (
    <div data-testid="component-name">
      {/* Component content */}
    </div>
  );
}
```

### API Route Structure
```typescript
// API routes should follow this pattern:
app.post("/api/endpoint", authenticateToken, async (req, res) => {
  try {
    if (!req.user) return res.sendStatus(401);
    
    const validatedData = schema.parse(req.body);
    const result = await storage.method(validatedData);
    
    res.json(result);
  } catch (error) {
    console.error("Endpoint error:", error);
    res.status(500).json({ error: "Error message" });
  }
});
```

## 🧪 Testing

### Running Tests
```bash
# Run all tests
npm test

# Run with coverage
npm run test:coverage

# Run specific test file
npm test -- --testNamePattern="ComponentName"

# Watch mode for development
npm run test:watch
```

### Writing Tests
- Write unit tests for utilities and helpers
- Write component tests for React components
- Write integration tests for API endpoints
- Use meaningful test descriptions
- Mock external dependencies appropriately

### Test Structure
```typescript
import { render, screen } from '@testing-library/react';
import { Component } from './Component';

describe('Component', () => {
  it('should render correctly', () => {
    render(<Component prop1="test" />);
    expect(screen.getByTestId('component-name')).toBeInTheDocument();
  });
  
  it('should handle user interaction', async () => {
    // Test implementation
  });
});
```

## 🗄️ Database Changes

### Schema Modifications
- Use Drizzle ORM for all database operations
- Create migrations for schema changes
- Update shared schemas in `shared/schema.ts`
- Test migrations thoroughly

### Migration Process
```bash
# Generate migration
npm run db:generate

# Apply migration
npm run db:migrate

# Reset database (development only)
npm run db:reset
```

## 🎨 UI/UX Guidelines

### Design System
- Use shadcn/ui components as the foundation
- Follow existing color scheme and typography
- Ensure responsive design for all screen sizes
- Maintain accessibility standards (WCAG 2.1)

### Component Guidelines
- Use semantic HTML elements
- Include proper ARIA labels
- Add `data-testid` attributes for testing
- Support both light and dark themes
- Ensure keyboard navigation works

## 🔐 Security Guidelines

### Authentication
- Never expose sensitive data in frontend
- Use proper JWT token handling
- Implement proper session management
- Validate all user inputs

### API Security
- Always authenticate protected endpoints
- Validate and sanitize all inputs
- Use proper error handling (don't expose internals)
- Implement rate limiting for public endpoints

### PayPal Integration
- Never hardcode API keys
- Use environment variables for all credentials
- Test with sandbox before live integration
- Verify webhook signatures

## 📦 Dependencies

### Adding Dependencies
- Check if functionality already exists in current dependencies
- Prefer well-maintained packages with good security records
- Update `package.json` and include justification in PR
- Consider bundle size impact

### Updating Dependencies
- Test thoroughly after updates
- Check for breaking changes
- Update related code if needed
- Document any migration steps

## 🚀 Performance Guidelines

### Frontend Performance
- Optimize images and media
- Use lazy loading for large components
- Implement proper caching strategies
- Minimize bundle size

### Backend Performance
- Optimize database queries
- Use proper indexing
- Implement connection pooling
- Cache frequently accessed data

## 📖 Documentation

### Code Documentation
- Document complex algorithms and business logic
- Use JSDoc for function documentation
- Keep README and guides up to date
- Include examples for complex features

### API Documentation
- Document all endpoints with examples
- Include request/response schemas
- Document error scenarios
- Keep Postman collection updated

## 🎯 Feature Development

### New Features
1. Discuss major features in GitHub Issues first
2. Break large features into smaller, reviewable PRs
3. Include tests and documentation
4. Consider backward compatibility
5. Update related documentation

### Feature Flags
- Use feature flags for experimental features
- Document flag behavior and cleanup plan
- Remove flags once features are stable

## 🔄 Review Process

### Pull Request Requirements
- [ ] Code follows style guidelines
- [ ] Tests pass and coverage is maintained
- [ ] Documentation is updated
- [ ] No security vulnerabilities introduced
- [ ] Performance impact considered
- [ ] Accessibility maintained

### Review Checklist
- Code quality and maintainability
- Test coverage and quality
- Security implications
- Performance impact
- Documentation completeness
- Breaking changes identified

## 🆘 Getting Help

### Communication Channels
- GitHub Issues for bugs and feature requests
- GitHub Discussions for general questions
- Discord: [VibeVerse Community](https://discord.gg/vibeverse)
- Email: dev@vibeverse.com

### Code of Conduct
- Be respectful and inclusive
- Provide constructive feedback
- Help others learn and grow
- Follow GitHub's Community Guidelines

---

Thank you for contributing to VibeVerse! Together we're building the future of creator monetization. 🚀