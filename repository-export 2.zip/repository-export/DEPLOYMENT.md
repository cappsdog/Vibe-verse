# VibeVerse Deployment Guide

## 🚀 Quick Deployment

### Option 1: Replit (Recommended)
1. Import this repository to Replit
2. Set environment variables in Secrets
3. Run `npm install` 
4. Run `npm run dev` to test
5. Click "Deploy" in Replit

### Option 2: Vercel
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel --prod
```

### Option 3: Railway
```bash
# Install Railway CLI
npm install -g @railway/cli

# Login and deploy
railway login
railway deploy
```

### Option 4: Heroku
```bash
# Create Heroku app
heroku create vibeverse-app

# Set environment variables
heroku config:set DATABASE_URL=your_db_url
heroku config:set PAYPAL_CLIENT_ID=your_client_id
# ... (add all other env vars)

# Deploy
git push heroku main
```

## 🔧 Environment Variables

Copy these to your deployment platform:

```bash
# Database
DATABASE_URL=postgresql://user:password@host:port/database

# PayPal Live Credentials
PAYPAL_CLIENT_ID=your_live_paypal_client_id
PAYPAL_CLIENT_SECRET=your_live_paypal_client_secret
PAYPAL_API_BASE=https://api-m.paypal.com
PLAN_BASIC_ID=P-your_basic_plan_id
PLAN_PRO_ID=P-your_creator_plan_id

# Session Security
SESSION_SECRET=your_very_secure_random_string_here

# Object Storage (Optional)
DEFAULT_OBJECT_STORAGE_BUCKET_ID=your_bucket_id
PUBLIC_OBJECT_SEARCH_PATHS=public/
PRIVATE_OBJECT_DIR=.private/

# Server Config
NODE_ENV=production
PORT=5000
```

## 🎯 PayPal Live Setup Checklist

### 1. Create Live PayPal Application
- [ ] Go to https://developer.paypal.com/dashboard/applications/live
- [ ] Click "Create App"
- [ ] App Name: "VibeVerse"
- [ ] Select your business account
- [ ] Features: Check "Subscriptions"
- [ ] Copy Client ID and Client Secret

### 2. Create Subscription Products & Plans
- [ ] Go to https://www.paypal.com/businessprofile/subscriptions/products
- [ ] Create Product: "VibeVerse Memberships"
- [ ] Create Basic Plan: £7.99/month
- [ ] Create Creator Plan: £19.99/month
- [ ] Copy both Plan IDs (start with "P-")

### 3. Configure Webhooks (Optional but Recommended)
- [ ] In PayPal Developer Dashboard → Webhooks
- [ ] Add webhook URL: `https://your-domain.com/api/paypal/webhook`
- [ ] Subscribe to events:
  - `BILLING.SUBSCRIPTION.ACTIVATED`
  - `BILLING.SUBSCRIPTION.CANCELLED`
  - `BILLING.SUBSCRIPTION.SUSPENDED`
  - `PAYMENT.CAPTURE.COMPLETED`

## 🗄️ Database Setup

### PostgreSQL (Recommended)
```bash
# Using Neon (Free tier available)
1. Sign up at https://neon.tech
2. Create new project
3. Copy connection string
4. Add to DATABASE_URL environment variable
```

### Alternative Database Providers
- **Supabase**: https://supabase.com (Free tier)
- **PlanetScale**: https://planetscale.com (MySQL)
- **Railway**: https://railway.app (PostgreSQL)

## 📦 Build Configuration

### package.json Scripts
```json
{
  "scripts": {
    "dev": "NODE_ENV=development tsx server/index.ts",
    "build": "npm run build:client && npm run build:server",
    "build:client": "vite build",
    "build:server": "tsc server/index.ts --outDir dist",
    "start": "node dist/index.js",
    "db:migrate": "drizzle-kit push:pg",
    "db:generate": "drizzle-kit generate:pg"
  }
}
```

### Dockerfile (Optional)
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 5000
CMD ["npm", "start"]
```

## 🔐 Security Checklist

- [ ] Environment variables secured
- [ ] PayPal webhooks configured with signature verification
- [ ] HTTPS enabled in production
- [ ] CORS configured for your domain
- [ ] Database connection encrypted
- [ ] Session secret is strong and unique
- [ ] No sensitive data in git repository

## 🎯 Performance Optimization

### 1. Database Optimization
- [ ] Database indices on frequently queried fields
- [ ] Connection pooling configured
- [ ] Query optimization with Drizzle

### 2. Frontend Optimization
- [ ] Code splitting enabled
- [ ] Image optimization
- [ ] Bundle size minimized
- [ ] CDN for static assets

### 3. Caching Strategy
- [ ] Redis for session storage (production)
- [ ] Browser caching headers
- [ ] API response caching

## 🧪 Testing Before Deployment

```bash
# 1. Test locally
npm run dev

# 2. Test production build
npm run build
npm start

# 3. Test key features
# - User registration/login
# - Post creation
# - PayPal subscription flow
# - Real-time messaging
# - File uploads
```

## 📊 Monitoring & Analytics

### Recommended Tools
- **Error Tracking**: Sentry
- **Analytics**: PostHog or Google Analytics
- **Uptime Monitoring**: Uptime Robot
- **Performance**: New Relic or DataDog

### Health Check Endpoint
```bash
GET /api/health
# Returns: {"status": "ok", "timestamp": "...", "uptime": "..."}
```

## 🚨 Troubleshooting

### Common Issues

1. **PayPal redirects to profile instead of login**
   - Ensure using live credentials (not sandbox)
   - Check PAYPAL_API_BASE is set to https://api-m.paypal.com

2. **Database connection errors**
   - Verify DATABASE_URL format
   - Check database server is accessible
   - Ensure SSL is configured if required

3. **Build failures**
   - Check Node.js version (18+ required)
   - Clear node_modules and reinstall
   - Verify all environment variables are set

4. **PayPal webhook verification failures**
   - Ensure webhook URL is HTTPS
   - Verify PAYPAL_WEBHOOK_ID is correct
   - Check webhook event types are subscribed

### Debug Mode
```bash
# Enable debug logging
DEBUG=vibeverse:* npm start
```

## 📈 Scaling Considerations

### For 80K+ Users
- [ ] Database read replicas
- [ ] Redis cluster for sessions
- [ ] Load balancer configuration
- [ ] CDN for media files
- [ ] Auto-scaling groups
- [ ] Database sharding strategy
- [ ] Microservices architecture
- [ ] Message queue for background jobs

---

**Ready to launch VibeVerse! 🚀**