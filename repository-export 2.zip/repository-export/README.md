# VibeVerse - Social Media Platform for Creators

A comprehensive social media platform focused on creator monetization and fan engagement. Features real-time messaging, voice/video calls, story features, and PayPal-integrated subscription services.

## 🚀 Features

- **Creator Monetization**: Three-tier subscription system (Free, Basic £7.99/mo, Creator £19.99/mo)
- **Premium Fan Subscriptions**: Variable pricing (£1.99-£99.99/mo) for exclusive creator content
- **Real-time Communication**: Direct messaging with voice/video calls via WebRTC
- **Daily Vibe Stories**: 24-hour temporary content similar to Instagram Stories
- **PayPal Integration**: Live payment processing connected to business account
- **80K Challenge**: Built for rapid scaling to 80,000 paid users

## 🛠 Tech Stack

### Frontend
- **React 18** with TypeScript
- **Vite** for fast development and building
- **Tailwind CSS** with shadcn/ui components
- **TanStack React Query** for server state management
- **Wouter** for lightweight routing
- **WebSocket** integration for real-time features

### Backend
- **Node.js** with Express.js
- **TypeScript** throughout
- **PostgreSQL** with Drizzle ORM
- **Passport.js** for authentication
- **WebSocket** server for real-time messaging
- **PayPal v2 REST API** for subscriptions

### Infrastructure
- **PostgreSQL** (Neon serverless)
- **Google Cloud Storage** for media assets
- **PayPal Live Environment** for payments
- **JWT** tokens with session management

## 📋 Prerequisites

- Node.js 18+ 
- PostgreSQL database
- PayPal Business account with live credentials
- Google Cloud Storage (optional, for media)

## 🔧 Installation

1. **Clone the repository**
```bash
git clone https://github.com/your-username/vibeverse.git
cd vibeverse
```

2. **Install dependencies**
```bash
npm install
```

3. **Environment Setup**
Create a `.env` file with the following variables:

```env
# Database
DATABASE_URL=your_postgresql_connection_string

# PayPal Live Credentials
PAYPAL_CLIENT_ID=your_live_client_id
PAYPAL_CLIENT_SECRET=your_live_client_secret
PAYPAL_API_BASE=https://api-m.paypal.com
PLAN_BASIC_ID=your_basic_plan_id
PLAN_PRO_ID=your_creator_plan_id

# Object Storage (Optional)
DEFAULT_OBJECT_STORAGE_BUCKET_ID=your_bucket_id
PUBLIC_OBJECT_SEARCH_PATHS=public/
PRIVATE_OBJECT_DIR=.private/

# Session Secret
SESSION_SECRET=your_secure_session_secret

# Server Configuration
PORT=5000
NODE_ENV=production
```

4. **Database Setup**
```bash
# Run migrations
npm run db:migrate

# (Optional) Seed with initial data
npm run db:seed
```

5. **Build and Start**
```bash
# Development
npm run dev

# Production
npm run build
npm start
```

## 🎯 PayPal Setup

1. **Create Live PayPal App**
   - Go to [PayPal Developer Dashboard](https://developer.paypal.com/dashboard/applications/live)
   - Create new app with "Subscriptions" feature
   - Copy Client ID and Secret

2. **Create Subscription Plans**
   - Visit [PayPal Business Profile](https://www.paypal.com/businessprofile/subscriptions/)
   - Create product: "VibeVerse Memberships"
   - Create plans: Basic (£7.99/mo) and Creator (£19.99/mo)
   - Copy Plan IDs

3. **Configure Webhooks**
   - Add webhook URL: `https://your-domain.com/api/paypal/webhook`
   - Subscribe to subscription events

## 🚀 Deployment

### Replit Deployment
```bash
# Build for production
npm run build

# Deploy
replit deploy
```

### Manual Deployment
```bash
# Build
npm run build

# Start production server
NODE_ENV=production npm start
```

## 📱 API Documentation

### Authentication
- `POST /api/register` - User registration
- `POST /api/login` - User login
- `POST /api/logout` - User logout
- `GET /api/user` - Get current user

### Posts
- `GET /api/posts` - Get posts feed
- `POST /api/posts` - Create new post
- `GET /api/posts/:id` - Get specific post

### Messages
- `GET /api/messages/conversations` - Get user conversations
- `GET /api/messages/:threadId` - Get messages in thread
- `POST /api/messages` - Send message

### Subscriptions
- `POST /api/paypal/subscription/create` - Create PayPal subscription
- `POST /api/paypal/subscription/confirm` - Confirm subscription

### Daily Vibes (Stories)
- `GET /api/daily-vibes` - Get active vibes
- `POST /api/daily-vibes` - Create new vibe
- `POST /api/daily-vibes/:id/view` - Mark vibe as viewed

## 🔐 Security Features

- JWT-based authentication
- Session management with secure cookies
- CORS protection
- Input validation with Zod schemas
- PayPal webhook signature verification
- Rate limiting on API endpoints

## 🎨 UI Components

Built with shadcn/ui components:
- Forms with validation
- Responsive design
- Dark/light mode support
- Accessible interfaces
- Mobile-optimized layouts

## 🧪 Testing

```bash
# Run tests
npm test

# Run with coverage
npm run test:coverage

# E2E tests
npm run test:e2e
```

## 📈 Performance

- Optimized bundle size with Vite
- Image optimization and lazy loading
- Database query optimization with Drizzle
- Real-time updates via WebSocket
- CDN integration for static assets

## 🤝 Contributing

1. Fork the repository
2. Create feature branch: `git checkout -b feature/amazing-feature`
3. Commit changes: `git commit -m 'Add amazing feature'`
4. Push to branch: `git push origin feature/amazing-feature`
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

For support and questions:
- Email: support@vibeverse.com
- Discord: [VibeVerse Community](https://discord.gg/vibeverse)
- Documentation: [docs.vibeverse.com](https://docs.vibeverse.com)

## 🎯 80K Challenge

VibeVerse is designed for rapid scaling. The platform architecture supports:
- High-concurrency real-time messaging
- Efficient database queries for large user bases
- Scalable payment processing
- CDN-optimized media delivery
- Automated creator payout systems

---

**Built with ❤️ for creators and their communities**