import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ui/theme-provider";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "./lib/protected-route";

// Pages
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import PlanSelectionPage from "@/pages/plan-selection-page";
import HomePage from "@/pages/home-page";
import MessagesPage from "@/pages/messages-page";
import CreatorDashboard from "@/pages/creator-dashboard";
import AdminPanel from "@/pages/admin-panel";
import PaymentSuccessPage from "@/pages/payment-success";
import FindFriendsPage from "@/pages/find-friends";

// Components
import Navigation from "@/components/navigation";

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <Route path="/register" component={PlanSelectionPage} />
      <Route path="/payment-success" component={PaymentSuccessPage} />
      <Route path="/" component={HomePage} />
      <Route path="/home" component={HomePage} />
      <ProtectedRoute path="/messages" component={MessagesPage} />
      <ProtectedRoute path="/creator" component={CreatorDashboard} />
      <ProtectedRoute path="/admin" component={AdminPanel} />
      <ProtectedRoute path="/find-friends" component={FindFriendsPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light" storageKey="vibeverse-theme">
        <AuthProvider>
          <TooltipProvider>
            <div className="min-h-screen bg-background">
              <Navigation />
              <Router />
              <Toaster />
            </div>
          </TooltipProvider>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
