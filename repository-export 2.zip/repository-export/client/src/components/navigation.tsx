import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Home, 
  MessageCircle, 
  Users, 
  Crown, 
  Settings, 
  LogOut,
  UserPlus
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export default function Navigation() {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  if (!user) return null;

  const isActive = (path: string) => location === path;

  return (
    <nav className="sticky top-0 z-50 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-vibe-purple to-vibe-pink rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">V</span>
              </div>
              <span className="font-bold text-xl bg-gradient-to-r from-vibe-purple to-vibe-pink bg-clip-text text-transparent">
                VibeVerse
              </span>
            </div>
          </Link>

          {/* Main Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            <Link href="/">
              <Button 
                variant={isActive("/") ? "default" : "ghost"} 
                size="sm"
                className={isActive("/") ? "bg-gradient-to-r from-vibe-purple to-vibe-pink" : ""}
                data-testid="nav-home"
              >
                <Home className="w-4 h-4 mr-2" />
                Home
              </Button>
            </Link>

            <Link href="/find-friends">
              <Button 
                variant={isActive("/find-friends") ? "default" : "ghost"} 
                size="sm"
                className={isActive("/find-friends") ? "bg-gradient-to-r from-vibe-purple to-vibe-pink" : ""}
                data-testid="nav-find-friends"
              >
                <UserPlus className="w-4 h-4 mr-2" />
                Find Friends
              </Button>
            </Link>

            <Link href="/messages">
              <Button 
                variant={isActive("/messages") ? "default" : "ghost"} 
                size="sm"
                className={isActive("/messages") ? "bg-gradient-to-r from-vibe-purple to-vibe-pink" : ""}
                data-testid="nav-messages"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Messages
              </Button>
            </Link>

            {(user.subscription?.plan === 'creator' || user.subscription?.plan === 'admin') && (
              <Link href="/creator">
                <Button 
                  variant={isActive("/creator") ? "default" : "ghost"} 
                  size="sm"
                  className={isActive("/creator") ? "bg-gradient-to-r from-vibe-purple to-vibe-pink" : ""}
                  data-testid="nav-creator"
                >
                  <Crown className="w-4 h-4 mr-2" />
                  Creator
                </Button>
              </Link>
            )}
          </div>

          {/* User Menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-10 w-10 rounded-full" data-testid="user-menu">
                <Avatar className="h-10 w-10">
                  <AvatarImage src={user.avatar || ""} alt="User avatar" />
                  <AvatarFallback className="bg-vibe-purple text-white">
                    {user.username.slice(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56" align="end" forceMount>
              <div className="flex items-center justify-start gap-2 p-2">
                <div className="flex flex-col space-y-1 leading-none">
                  <p className="font-medium">{user.username}</p>
                  <p className="w-[200px] truncate text-sm text-muted-foreground">
                    {user.email}
                  </p>
                </div>
              </div>
              <DropdownMenuSeparator />
              
              {/* Mobile Navigation Items */}
              <div className="md:hidden">
                <Link href="/">
                  <DropdownMenuItem>
                    <Home className="mr-2 h-4 w-4" />
                    <span>Home</span>
                  </DropdownMenuItem>
                </Link>
                <Link href="/find-friends">
                  <DropdownMenuItem>
                    <UserPlus className="mr-2 h-4 w-4" />
                    <span>Find Friends</span>
                  </DropdownMenuItem>
                </Link>
                <Link href="/messages">
                  <DropdownMenuItem>
                    <MessageCircle className="mr-2 h-4 w-4" />
                    <span>Messages</span>
                  </DropdownMenuItem>
                </Link>
                {(user.subscription?.plan === 'creator' || user.subscription?.plan === 'admin') && (
                  <Link href="/creator">
                    <DropdownMenuItem>
                      <Crown className="mr-2 h-4 w-4" />
                      <span>Creator Dashboard</span>
                    </DropdownMenuItem>
                  </Link>
                )}
                <DropdownMenuSeparator />
              </div>

              <DropdownMenuItem>
                <Settings className="mr-2 h-4 w-4" />
                <span>Settings</span>
              </DropdownMenuItem>
              
              <DropdownMenuSeparator />
              
              <DropdownMenuItem onClick={logout} data-testid="logout-button">
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </nav>
  );
}