import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Image, Video, X, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

interface PostCreatorProps {
  onClose?: () => void;
  isOpen?: boolean;
}

export default function PostCreator({ onClose, isOpen = true }: PostCreatorProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [postData, setPostData] = useState({
    title: "",
    body: "",
    visibility: "public" as "public" | "premium",
    media: [] as Array<{ type: "image" | "video"; url: string; alt?: string }>
  });
  const [mediaInput, setMediaInput] = useState({ url: "", alt: "", type: "image" as "image" | "video" });

  const createPostMutation = useMutation({
    mutationFn: async (data: typeof postData) => {
      const response = await fetch('/api/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(data)
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(error || 'Failed to create post');
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Post Created!",
        description: "Your post has been published successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      setPostData({ title: "", body: "", visibility: "public", media: [] });
      onClose?.();
    },
    onError: (error) => {
      toast({
        title: "Failed to Create Post",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!postData.body.trim()) {
      toast({
        title: "Post Content Required",
        description: "Please write something for your post.",
        variant: "destructive",
      });
      return;
    }
    
    try {
      createPostMutation.mutate(postData);
    } catch (error) {
      console.error('Post creation error:', error);
      toast({
        title: "Post Creation Failed",
        description: "There was an error creating your post. Please try again.",
        variant: "destructive",
      });
    }
  };

  const addMedia = () => {
    if (!mediaInput.url.trim()) return;
    
    setPostData(prev => ({
      ...prev,
      media: [...prev.media, { ...mediaInput }]
    }));
    setMediaInput({ url: "", alt: "", type: "image" });
  };

  const removeMedia = (index: number) => {
    setPostData(prev => ({
      ...prev,
      media: prev.media.filter((_, i) => i !== index)
    }));
  };

  if (!isOpen || !user) return null;

  return (
    <Card className="w-full max-w-2xl mx-auto bg-white/95 backdrop-blur-sm border-0 shadow-2xl">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-xl font-bold text-gray-900">
          Create New Post
        </CardTitle>
        {onClose && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            data-testid="button-close-post-creator"
          >
            <X className="w-4 h-4" />
          </Button>
        )}
      </CardHeader>
      
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Title (Optional) */}
          <div className="space-y-2">
            <Label htmlFor="post-title">Title (Optional)</Label>
            <Input
              id="post-title"
              data-testid="input-post-title"
              type="text"
              value={postData.title}
              onChange={(e) => setPostData(prev => ({ ...prev, title: e.target.value }))}
              placeholder="Add a catchy title..."
              maxLength={100}
            />
          </div>

          {/* Content */}
          <div className="space-y-2">
            <Label htmlFor="post-body">What's on your mind? *</Label>
            <Textarea
              id="post-body"
              data-testid="textarea-post-body"
              value={postData.body}
              onChange={(e) => setPostData(prev => ({ ...prev, body: e.target.value }))}
              placeholder="Share your thoughts, updates, or creative content..."
              rows={4}
              maxLength={2000}
              required
            />
            <div className="text-xs text-gray-500 text-right">
              {postData.body.length}/2000 characters
            </div>
          </div>

          {/* Visibility */}
          <div className="space-y-2">
            <Label htmlFor="post-visibility">Visibility</Label>
            <Select 
              value={postData.visibility} 
              onValueChange={(value: "public" | "premium") => 
                setPostData(prev => ({ ...prev, visibility: value }))
              }
            >
              <SelectTrigger data-testid="select-post-visibility">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="public">Public - Everyone can see</SelectItem>
                <SelectItem value="premium">Premium - Only subscribers</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Media Upload */}
          <div className="space-y-3">
            <Label>Add Media (Optional)</Label>
            
            {/* Media Input */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
              <div className="md:col-span-2">
                <Input
                  placeholder="Media URL (image or video)"
                  value={mediaInput.url}
                  onChange={(e) => setMediaInput(prev => ({ ...prev, url: e.target.value }))}
                  data-testid="input-media-url"
                />
              </div>
              <Select 
                value={mediaInput.type} 
                onValueChange={(value: "image" | "video") => 
                  setMediaInput(prev => ({ ...prev, type: value }))
                }
              >
                <SelectTrigger data-testid="select-media-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="image">Image</SelectItem>
                  <SelectItem value="video">Video</SelectItem>
                </SelectContent>
              </Select>
              <Button
                type="button"
                variant="outline"
                onClick={addMedia}
                disabled={!mediaInput.url.trim()}
                data-testid="button-add-media"
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>

            {/* Alt text for accessibility */}
            {mediaInput.url && (
              <Input
                placeholder="Alt text (describe the media for accessibility)"
                value={mediaInput.alt}
                onChange={(e) => setMediaInput(prev => ({ ...prev, alt: e.target.value }))}
                data-testid="input-media-alt"
              />
            )}

            {/* Media Preview */}
            {postData.media.length > 0 && (
              <div className="space-y-2">
                <Label>Media Attachments:</Label>
                <div className="space-y-2">
                  {postData.media.map((item, index) => (
                    <div key={index} className="flex items-center justify-between bg-gray-50 p-2 rounded-lg">
                      <div className="flex items-center space-x-2">
                        {item.type === "image" ? (
                          <Image className="w-4 h-4 text-blue-500" />
                        ) : (
                          <Video className="w-4 h-4 text-purple-500" />
                        )}
                        <span className="text-sm truncate max-w-xs">{item.url}</span>
                        {item.alt && <span className="text-xs text-gray-500">({item.alt})</span>}
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removeMedia(index)}
                        data-testid={`button-remove-media-${index}`}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Submit Button */}
          <div className="flex gap-3 pt-4">
            {onClose && (
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="flex-1"
                data-testid="button-cancel-post"
              >
                Cancel
              </Button>
            )}
            <Button
              type="submit"
              disabled={createPostMutation.isPending || !postData.body.trim()}
              className="flex-1 bg-gradient-to-r from-vibe-purple to-vibe-pink hover:opacity-90"
              data-testid="button-submit-post"
            >
              {createPostMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Publishing...
                </>
              ) : (
                "Publish Post"
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}