import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { 
  Shield, 
  Users, 
  TrendingUp, 
  Crown, 
  AlertTriangle,
  Flag,
  MessageSquare,
  Eye,
  Settings,
  DollarSign,
  Calendar,
  Activity
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

interface AdminStats {
  totalUsers: number;
  monthlyRevenue: number;
  activeCreators: number;
  pendingReports: number;
}

interface Report {
  id: string;
  reporterId: string;
  targetType: string;
  targetId: string;
  reason: string;
  status: string;
  createdAt: string;
}

interface PlatformSettings {
  platformFeePercent: string;
  payoutThresholdGBP: string;
  trialDays: number;
  maxStorySec: number;
}

export default function AdminPanel() {
  const { user } = useAuth();
  const [settings, setSettings] = useState<PlatformSettings>({
    platformFeePercent: "40",
    payoutThresholdGBP: "50",
    trialDays: 7,
    maxStorySec: 60
  });

  const { data: adminStats, isLoading: statsLoading } = useQuery<AdminStats>({
    queryKey: ["/api/admin/stats"],
  });

  const { data: reports = [], isLoading: reportsLoading, refetch: refetchReports } = useQuery<Report[]>({
    queryKey: ["/api/admin/reports"],
  });

  const { data: platformSettings, isLoading: settingsLoading } = useQuery<PlatformSettings>({
    queryKey: ["/api/admin/settings"],
    onSuccess: (data) => {
      if (data) setSettings(data);
    }
  });

  const handleReportAction = async (reportId: string, status: string) => {
    try {
      await fetch(`/api/admin/reports/${reportId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ status })
      });
      refetchReports();
    } catch (error) {
      console.error("Failed to update report:", error);
    }
  };

  const handleSettingsUpdate = async () => {
    try {
      await fetch("/api/admin/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(settings)
      });
    } catch (error) {
      console.error("Failed to update settings:", error);
    }
  };

  // Check if user is admin
  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center py-12">
                <Shield className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Access Denied</h3>
                <p className="text-muted-foreground">
                  You need administrator privileges to access this page.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (statsLoading || reportsLoading || settingsLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center">
            <Shield className="w-8 h-8 text-primary mr-3" />
            <div>
              <h1 className="text-3xl font-bold text-foreground" data-testid="text-admin-title">Admin Dashboard</h1>
              <p className="text-muted-foreground">Platform management and moderation tools</p>
            </div>
          </div>
        </div>

        {/* Admin Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card data-testid="card-total-users">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Total Users</p>
                  <p className="text-2xl font-bold text-foreground">
                    {adminStats ? adminStats.totalUsers.toLocaleString() : "0"}
                  </p>
                  <p className="text-sm text-green-500">+8.2% this month</p>
                </div>
                <div className="w-12 h-12 bg-instagram-blue/10 rounded-xl flex items-center justify-center">
                  <Users className="w-6 h-6 text-instagram-blue" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card data-testid="card-monthly-revenue">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Monthly Revenue</p>
                  <p className="text-2xl font-bold text-foreground">
                    £{adminStats ? adminStats.monthlyRevenue.toLocaleString() : "0"}
                  </p>
                  <p className="text-sm text-green-500">+15.7% from last month</p>
                </div>
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card data-testid="card-active-creators">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Active Creators</p>
                  <p className="text-2xl font-bold text-foreground">
                    {adminStats ? adminStats.activeCreators.toLocaleString() : "0"}
                  </p>
                  <p className="text-sm text-green-500">+23 new this week</p>
                </div>
                <div className="w-12 h-12 bg-vibe-purple/10 rounded-xl flex items-center justify-center">
                  <Crown className="w-6 h-6 text-vibe-purple" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card data-testid="card-pending-reports">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Pending Reports</p>
                  <p className="text-2xl font-bold text-foreground">
                    {adminStats ? adminStats.pendingReports : reports.length}
                  </p>
                  <p className="text-sm text-red-500">3 high priority</p>
                </div>
                <div className="w-12 h-12 bg-red-100 dark:bg-red-900 rounded-xl flex items-center justify-center">
                  <AlertTriangle className="w-6 h-6 text-red-600 dark:text-red-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Admin Panels */}
        <div className="grid lg:grid-cols-2 gap-8">
          
          {/* Content Moderation */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Flag className="w-5 h-5 mr-2" />
                Content Moderation Queue
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              
              {reports.length === 0 ? (
                <div className="text-center py-8">
                  <Eye className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">No pending reports</p>
                </div>
              ) : (
                reports.slice(0, 3).map((report) => {
                  const isPriority = report.reason.toLowerCase().includes("inappropriate") || 
                                   report.reason.toLowerCase().includes("spam");
                  const bgColor = isPriority ? "bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800" : 
                                 report.reason.toLowerCase().includes("spam") ? "bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800" :
                                 "bg-muted";
                  
                  return (
                    <div key={report.id} className={`flex items-center justify-between p-4 rounded-xl border ${bgColor}`}>
                      <div className="flex items-center">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center mr-4 ${
                          isPriority ? "bg-red-100 dark:bg-red-900" :
                          report.reason.toLowerCase().includes("spam") ? "bg-yellow-100 dark:bg-yellow-900" :
                          "bg-muted"
                        }`}>
                          {isPriority ? <Flag className="w-5 h-5 text-red-600 dark:text-red-400" /> :
                           report.reason.toLowerCase().includes("spam") ? <MessageSquare className="w-5 h-5 text-yellow-600 dark:text-yellow-400" /> :
                           <Eye className="w-5 h-5 text-muted-foreground" />}
                        </div>
                        <div>
                          <h4 className="font-semibold text-foreground text-sm">
                            {report.reason}
                          </h4>
                          <p className="text-xs text-muted-foreground">
                            {report.targetType} • Reporter: {report.reporterId.slice(-8)}
                          </p>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button 
                          size="sm" 
                          variant="destructive" 
                          className="text-xs px-3 py-1"
                          onClick={() => handleReportAction(report.id, "resolved")}
                          data-testid={`button-remove-${report.id}`}
                        >
                          {isPriority ? "Remove" : "Remove"}
                        </Button>
                        <Button 
                          size="sm" 
                          variant="secondary" 
                          className="text-xs px-3 py-1"
                          onClick={() => handleReportAction(report.id, "dismissed")}
                          data-testid={`button-approve-${report.id}`}
                        >
                          {isPriority ? "Dismiss" : "Approve"}
                        </Button>
                      </div>
                    </div>
                  );
                })
              )}
              
              {reports.length > 3 && (
                <Button variant="outline" className="w-full" data-testid="button-view-all-reports">
                  View All Reports ({reports.length})
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Platform Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="w-5 h-5 mr-2" />
                Platform Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              
              {/* Revenue Settings */}
              <div>
                <h4 className="font-medium text-foreground mb-3">Revenue Settings</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="platform-fee" className="text-sm text-muted-foreground">
                      Platform Fee (%)
                    </Label>
                    <div className="flex items-center">
                      <Input
                        id="platform-fee"
                        type="number"
                        value={settings.platformFeePercent}
                        onChange={(e) => setSettings({...settings, platformFeePercent: e.target.value})}
                        className="w-16 px-2 py-1 text-sm text-right"
                        data-testid="input-platform-fee"
                      />
                      <span className="text-sm text-muted-foreground ml-2">%</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="payout-threshold" className="text-sm text-muted-foreground">
                      Payout Threshold
                    </Label>
                    <div className="flex items-center">
                      <span className="text-sm text-muted-foreground mr-2">£</span>
                      <Input
                        id="payout-threshold"
                        type="number"
                        value={settings.payoutThresholdGBP}
                        onChange={(e) => setSettings({...settings, payoutThresholdGBP: e.target.value})}
                        className="w-20 px-2 py-1 text-sm text-right"
                        data-testid="input-payout-threshold"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Content Settings */}
              <div>
                <h4 className="font-medium text-foreground mb-3">Content Settings</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="story-duration" className="text-sm text-muted-foreground">
                      Max Story Duration (sec)
                    </Label>
                    <Input
                      id="story-duration"
                      type="number"
                      value={settings.maxStorySec}
                      onChange={(e) => setSettings({...settings, maxStorySec: parseInt(e.target.value)})}
                      className="w-20 px-2 py-1 text-sm text-right"
                      data-testid="input-story-duration"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label className="text-sm text-muted-foreground">
                      DM Attachment Size (MB)
                    </Label>
                    <Input
                      type="number"
                      defaultValue="25"
                      className="w-20 px-2 py-1 text-sm text-right"
                      data-testid="input-attachment-size"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="trial-days" className="text-sm text-muted-foreground">
                      Free Trial Days
                    </Label>
                    <Input
                      id="trial-days"
                      type="number"
                      value={settings.trialDays}
                      onChange={(e) => setSettings({...settings, trialDays: parseInt(e.target.value)})}
                      className="w-20 px-2 py-1 text-sm text-right"
                      data-testid="input-trial-days"
                    />
                  </div>
                </div>
              </div>

              <Separator />

              {/* Moderation Settings */}
              <div>
                <h4 className="font-medium text-foreground mb-3">Moderation</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm text-muted-foreground">
                      Auto-moderation
                    </Label>
                    <Switch defaultChecked data-testid="switch-auto-moderation" />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label className="text-sm text-muted-foreground">
                      Profanity Filter
                    </Label>
                    <Switch defaultChecked data-testid="switch-profanity-filter" />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label className="text-sm text-muted-foreground">
                      Auto-ban Spam Accounts
                    </Label>
                    <Switch defaultChecked data-testid="switch-auto-ban-spam" />
                  </div>
                </div>
              </div>

              <Button 
                onClick={handleSettingsUpdate} 
                className="w-full bg-gradient-to-r from-instagram-blue to-vibe-purple text-white"
                data-testid="button-save-settings"
              >
                Save Settings
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="w-5 h-5 mr-2" />
              Recent Platform Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mr-3">
                    <Users className="w-4 h-4 text-green-600 dark:text-green-400" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground text-sm">New user registrations</p>
                    <p className="text-xs text-muted-foreground">247 new users in the last 24 hours</p>
                  </div>
                </div>
                <Badge variant="secondary">+12.5%</Badge>
              </div>

              <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-vibe-purple/10 rounded-full flex items-center justify-center mr-3">
                    <Crown className="w-4 h-4 text-vibe-purple" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground text-sm">Creator applications</p>
                    <p className="text-xs text-muted-foreground">23 new creator profiles created</p>
                  </div>
                </div>
                <Badge variant="secondary">+8.7%</Badge>
              </div>

              <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-instagram-blue/10 rounded-full flex items-center justify-center mr-3">
                    <DollarSign className="w-4 h-4 text-instagram-blue" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground text-sm">Revenue growth</p>
                    <p className="text-xs text-muted-foreground">£12,485 processed in subscriptions</p>
                  </div>
                </div>
                <Badge variant="secondary" className="bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300">
                  +15.7%
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
