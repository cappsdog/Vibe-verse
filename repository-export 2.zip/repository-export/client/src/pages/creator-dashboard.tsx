import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { 
  TrendingUp, 
  Users, 
  Crown, 
  Heart, 
  DollarSign, 
  Calendar,
  Download,
  Settings,
  BarChart3,
  PieChart,
  Target
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import PayPalButton from "@/components/PayPalButton";

interface CreatorStats {
  profile: any;
  balance: any;
  stats: {
    monthlyEarnings: string;
    premiumSubscribers: number;
    totalFollowers: number;
    totalPosts: number;
    engagementRate: string;
  };
  recentTransactions: any[];
}

export default function CreatorDashboard() {
  const { user } = useAuth();
  const [payoutEmail, setPayoutEmail] = useState("");
  const [payoutAmount, setPayoutAmount] = useState("");
  const [showPayoutForm, setShowPayoutForm] = useState(false);

  const { data: creatorStats, isLoading, refetch } = useQuery<CreatorStats>({
    queryKey: ["/api/creator/stats"],
  });

  const handlePayoutRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch("/api/creator/payout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          paypalEmail,
          amount: payoutAmount
        })
      });

      if (response.ok) {
        setShowPayoutForm(false);
        setPayoutEmail("");
        setPayoutAmount("");
        refetch();
      } else {
        const error = await response.json();
        console.error("Payout error:", error);
      }
    } catch (error) {
      console.error("Payout request failed:", error);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!creatorStats) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center py-12">
                <Crown className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Creator Profile Not Found</h3>
                <p className="text-muted-foreground mb-4">
                  You need to create a creator profile to access the dashboard.
                </p>
                <Button>Create Creator Profile</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground" data-testid="text-dashboard-title">Creator Dashboard</h1>
              <p className="text-muted-foreground">Manage your content and earnings</p>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-muted-foreground">Last updated: 2 hours ago</span>
              <Button className="bg-gradient-to-r from-vibe-purple to-vibe-pink text-white" data-testid="button-create-post">
                Create Post
              </Button>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card data-testid="card-monthly-earnings">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Monthly Earnings</p>
                  <p className="text-2xl font-bold text-foreground">£{creatorStats.stats.monthlyEarnings}</p>
                  <p className="text-sm text-green-500">+12.5% from last month</p>
                </div>
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-xl flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card data-testid="card-premium-subscribers">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Premium Subscribers</p>
                  <p className="text-2xl font-bold text-foreground">{creatorStats.stats.premiumSubscribers}</p>
                  <p className="text-sm text-green-500">+23 new this week</p>
                </div>
                <div className="w-12 h-12 bg-vibe-purple/10 rounded-xl flex items-center justify-center">
                  <Crown className="w-6 h-6 text-vibe-purple" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card data-testid="card-total-followers">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Total Followers</p>
                  <p className="text-2xl font-bold text-foreground">{(creatorStats.stats.totalFollowers / 1000).toFixed(1)}k</p>
                  <p className="text-sm text-green-500">+5.2% growth rate</p>
                </div>
                <div className="w-12 h-12 bg-instagram-blue/10 rounded-xl flex items-center justify-center">
                  <Users className="w-6 h-6 text-instagram-blue" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card data-testid="card-engagement-rate">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Engagement Rate</p>
                  <p className="text-2xl font-bold text-foreground">{creatorStats.stats.engagementRate}%</p>
                  <p className="text-sm text-red-500">-0.3% from last week</p>
                </div>
                <div className="w-12 h-12 bg-tiktok-red/10 rounded-xl flex items-center justify-center">
                  <Heart className="w-6 h-6 text-tiktok-red" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts and Analytics */}
        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          
          {/* Earnings Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart3 className="w-5 h-5 mr-2" />
                Earnings Overview
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 bg-muted rounded-xl flex items-center justify-center mb-4">
                <div className="text-center text-muted-foreground">
                  <TrendingUp className="w-12 h-12 mx-auto mb-2" />
                  <p className="font-medium">Earnings Chart</p>
                  <p className="text-sm">Revenue trends and projections</p>
                </div>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Last 30 days</span>
                <span className="text-green-500 font-semibold">+£1,247 vs previous period</span>
              </div>
            </CardContent>
          </Card>

          {/* Subscriber Growth */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <PieChart className="w-5 h-5 mr-2" />
                Subscriber Growth
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 bg-muted rounded-xl flex items-center justify-center mb-4">
                <div className="text-center text-muted-foreground">
                  <Target className="w-12 h-12 mx-auto mb-2" />
                  <p className="font-medium">Growth Chart</p>
                  <p className="text-sm">Follower and subscriber trends</p>
                </div>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Growth rate</span>
                <span className="text-vibe-purple font-semibold">+5.2% monthly</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Revenue Breakdown and Fan Management */}
        <div className="grid lg:grid-cols-3 gap-8">
          
          {/* Revenue Breakdown */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Revenue Breakdown</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                
                <div className="flex items-center justify-between p-4 bg-muted rounded-xl">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center mr-4">
                      <Crown className="w-5 h-5 text-green-600 dark:text-green-400" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">Premium Subscriptions</h4>
                      <p className="text-sm text-muted-foreground">847 active subscribers at £9.99/month</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-foreground">£8,465</p>
                    <p className="text-sm text-muted-foreground">60% share</p>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-muted rounded-xl">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-vibe-purple/10 rounded-lg flex items-center justify-center mr-4">
                      <Heart className="w-5 h-5 text-vibe-purple" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">Tips & Donations</h4>
                      <p className="text-sm text-muted-foreground">Direct fan support</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-foreground">£1,247</p>
                    <p className="text-sm text-muted-foreground">60% share</p>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-muted rounded-xl">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-instagram-blue/10 rounded-lg flex items-center justify-center mr-4">
                      <Settings className="w-5 h-5 text-instagram-blue" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">Digital Products</h4>
                      <p className="text-sm text-muted-foreground">Art prints, tutorials, presets</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-foreground">£847</p>
                    <p className="text-sm text-muted-foreground">60% share</p>
                  </div>
                </div>

                {/* Payout Section */}
                <Separator className="my-6" />
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-semibold text-foreground">Available for Payout</h4>
                    <Button 
                      onClick={() => setShowPayoutForm(true)}
                      className="bg-green-600 hover:bg-green-700 text-white"
                      data-testid="button-request-payout"
                    >
                      Request Payout
                    </Button>
                  </div>
                  
                  <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-xl">
                    <p className="text-2xl font-bold text-green-700 dark:text-green-400" data-testid="text-available-balance">
                      £{creatorStats.balance?.availableGBP || "0.00"}
                    </p>
                    <p className="text-sm text-green-600 dark:text-green-500 mt-1">
                      Ready for withdrawal to PayPal
                    </p>
                  </div>

                  {/* Payout Form Modal */}
                  {showPayoutForm && (
                    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                      <Card className="w-full max-w-md">
                        <CardHeader>
                          <CardTitle>Request Payout</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <form onSubmit={handlePayoutRequest} className="space-y-4">
                            <div>
                              <Label htmlFor="payout-email">PayPal Email</Label>
                              <Input
                                id="payout-email"
                                type="email"
                                value={payoutEmail}
                                onChange={(e) => setPayoutEmail(e.target.value)}
                                placeholder="your@paypal.email"
                                required
                                data-testid="input-payout-email"
                              />
                            </div>
                            
                            <div>
                              <Label htmlFor="payout-amount">Amount (£)</Label>
                              <Input
                                id="payout-amount"
                                type="number"
                                step="0.01"
                                min="50"
                                max={creatorStats.balance?.availableGBP || "0"}
                                value={payoutAmount}
                                onChange={(e) => setPayoutAmount(e.target.value)}
                                placeholder="50.00"
                                required
                                data-testid="input-payout-amount"
                              />
                              <p className="text-sm text-muted-foreground mt-1">
                                Minimum: £50.00, Available: £{creatorStats.balance?.availableGBP || "0.00"}
                              </p>
                            </div>
                            
                            <div className="flex gap-2">
                              <Button 
                                type="button" 
                                variant="outline" 
                                className="flex-1"
                                onClick={() => setShowPayoutForm(false)}
                                data-testid="button-cancel-payout"
                              >
                                Cancel
                              </Button>
                              <Button 
                                type="submit" 
                                className="flex-1"
                                data-testid="button-confirm-payout"
                              >
                                Request Payout
                              </Button>
                            </div>
                          </form>
                        </CardContent>
                      </Card>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Top Supporters */}
          <Card>
            <CardHeader>
              <CardTitle>Top Supporters</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Avatar className="h-10 w-10 mr-3">
                    <AvatarImage src="" alt="Fan avatar" />
                    <AvatarFallback>MC</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold text-foreground text-sm">mike_collector</p>
                    <p className="text-xs text-muted-foreground">Premium subscriber</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold text-foreground">£247</p>
                  <p className="text-xs text-muted-foreground">6 months</p>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Avatar className="h-10 w-10 mr-3">
                    <AvatarImage src="" alt="Fan avatar" />
                    <AvatarFallback>AJ</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold text-foreground text-sm">art_lover_jane</p>
                    <p className="text-xs text-muted-foreground">Premium subscriber</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold text-foreground">£199</p>
                  <p className="text-xs text-muted-foreground">4 months</p>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Avatar className="h-10 w-10 mr-3">
                    <AvatarImage src="" alt="Fan avatar" />
                    <AvatarFallback>CD</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold text-foreground text-sm">creative_david</p>
                    <p className="text-xs text-muted-foreground">Premium subscriber</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold text-foreground">£149</p>
                  <p className="text-xs text-muted-foreground">3 months</p>
                </div>
              </div>

              {/* Subscription Settings */}
              <Separator className="my-6" />
              
              <div>
                <h4 className="font-semibold text-foreground mb-4">Subscription Settings</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Monthly Price</span>
                    <div className="flex items-center">
                      <span className="text-sm font-semibold text-foreground mr-2">
                        £{creatorStats.profile?.premiumPriceGBP || "9.99"}
                      </span>
                      <Button variant="ghost" size="sm" className="text-xs">
                        Edit
                      </Button>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Free Trial</span>
                    <div className="flex items-center">
                      <Badge variant="secondary" className="text-xs">
                        7 days
                      </Badge>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
