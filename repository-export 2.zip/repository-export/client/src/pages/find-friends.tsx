import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Search, UserPlus, Crown, MessageCircle, Users } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

interface SearchUser {
  id: string;
  username: string;
  email: string;
  avatar?: string;
  subscription?: {
    plan: string;
    status: string;
  };
  isCreator?: boolean;
  followerCount?: number;
  postCount?: number;
}

export default function FindFriendsPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const { user } = useAuth();
  const { toast } = useToast();

  const { data: searchResults, isLoading } = useQuery({
    queryKey: ['/api/users/search', searchQuery],
    enabled: searchQuery.length >= 2,
    staleTime: 30000, // Cache for 30 seconds
  });

  const { data: suggestedUsers } = useQuery({
    queryKey: ['/api/users/suggested'],
    staleTime: 300000, // Cache for 5 minutes
  });

  const handleFollow = async (userId: string) => {
    try {
      const response = await fetch(`/api/users/${userId}/follow`, {
        method: 'POST',
        credentials: 'include',
      });

      if (response.ok) {
        toast({
          title: "Following!",
          description: "You're now following this user.",
        });
      } else {
        throw new Error('Failed to follow user');
      }
    } catch (error) {
      toast({
        title: "Follow Failed",
        description: "Unable to follow this user. Please try again.",
        variant: "destructive",
      });
    }
  };

  const UserCard = ({ user: searchUser }: { user: SearchUser }) => (
    <Card className="hover:shadow-lg transition-shadow">
      <CardContent className="pt-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Avatar className="h-12 w-12">
              <AvatarImage src={searchUser.avatar || ""} alt={searchUser.username} />
              <AvatarFallback className="bg-vibe-purple text-white">
                {searchUser.username.slice(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-semibold text-foreground">{searchUser.username}</h3>
                {searchUser.subscription?.plan === 'creator' && (
                  <Crown className="w-4 h-4 text-yellow-500" />
                )}
              </div>
              
              {searchUser.subscription?.plan && (
                <Badge 
                  variant={searchUser.subscription.plan === 'creator' ? 'default' : 'secondary'}
                  className={searchUser.subscription.plan === 'creator' 
                    ? 'bg-gradient-to-r from-vibe-purple to-vibe-pink text-white' 
                    : ''
                  }
                >
                  {searchUser.subscription.plan.charAt(0).toUpperCase() + searchUser.subscription.plan.slice(1)}
                </Badge>
              )}
              
              {(searchUser.followerCount || searchUser.postCount) && (
                <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                  {searchUser.followerCount && (
                    <span className="flex items-center gap-1">
                      <Users className="w-3 h-3" />
                      {searchUser.followerCount} followers
                    </span>
                  )}
                  {searchUser.postCount && (
                    <span>{searchUser.postCount} posts</span>
                  )}
                </div>
              )}
            </div>
          </div>
          
          <div className="flex gap-2">
            <Button 
              size="sm" 
              variant="outline"
              onClick={() => handleFollow(searchUser.id)}
              data-testid={`button-follow-${searchUser.id}`}
            >
              <UserPlus className="w-4 h-4 mr-1" />
              Follow
            </Button>
            <Link href={`/messages?user=${searchUser.id}`}>
              <Button size="sm" variant="ghost" data-testid={`button-message-${searchUser.id}`}>
                <MessageCircle className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Find Friends & Creators</h1>
          <p className="text-muted-foreground">
            Discover amazing creators and connect with friends on VibeVerse
          </p>
        </div>

        {/* Search Section */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="w-5 h-5" />
              Search Users
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                type="text"
                placeholder="Search by username..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search-users"
              />
            </div>
            
            {searchQuery.length > 0 && searchQuery.length < 2 && (
              <p className="text-sm text-muted-foreground mt-2">
                Enter at least 2 characters to search
              </p>
            )}
          </CardContent>
        </Card>

        {/* Search Results */}
        {searchQuery.length >= 2 && (
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4">Search Results</h2>
            
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : searchResults && searchResults.length > 0 ? (
              <div className="space-y-4">
                {searchResults.map((user: SearchUser) => (
                  <UserCard key={user.id} user={user} />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="pt-6 text-center">
                  <p className="text-muted-foreground">No users found matching "{searchQuery}"</p>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {/* Suggested Users */}
        {(!searchQuery || searchQuery.length < 2) && (
          <div>
            <h2 className="text-xl font-semibold mb-4">Suggested for You</h2>
            
            {suggestedUsers && suggestedUsers.length > 0 ? (
              <div className="space-y-4">
                {suggestedUsers.map((user: SearchUser) => (
                  <UserCard key={user.id} user={user} />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="space-y-4">
                    <div className="w-16 h-16 bg-gradient-to-r from-vibe-purple to-vibe-pink rounded-full flex items-center justify-center mx-auto">
                      <Users className="w-8 h-8 text-white" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Welcome to the Community!</h3>
                      <p className="text-muted-foreground mb-4">
                        Use the search above to find friends and creators to follow.
                      </p>
                      <div className="text-sm text-muted-foreground">
                        <p>💡 Try searching for usernames or creator handles</p>
                        <p>🎯 Follow creators to see their exclusive content</p>
                        <p>💬 Start conversations with direct messages</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}