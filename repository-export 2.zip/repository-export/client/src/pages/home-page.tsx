import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Heart, MessageCircle, Share2, Bookmark, Plus, Crown, Video, Phone, Edit3 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import PostCreator from "@/components/post-creator";

interface Post {
  id: string;
  creatorId: string;
  title?: string;
  body: string;
  media: Array<{ type: string; url: string; alt?: string }>;
  visibility: string;
  stats: {
    likes: number;
    comments: number;
    shares: number;
  };
  createdAt: string;
}

interface DailyVibe {
  id: string;
  creatorId: string;
  media: { type: string; url: string; duration?: number };
  caption?: string;
  visibility: string;
  createdAt: string;
}

export default function HomePage() {
  const { user } = useAuth();
  const [selectedStory, setSelectedStory] = useState<string | null>(null);
  const [showPostCreator, setShowPostCreator] = useState(false);

  const { data: posts = [], isLoading: postsLoading } = useQuery<Post[]>({
    queryKey: ["/api/posts"],
    enabled: !!user, // Only fetch if user is authenticated
  });

  const { data: dailyVibes = [], isLoading: vibesLoading } = useQuery<DailyVibe[]>({
    queryKey: ["/api/daily-vibes"],
    enabled: !!user, // Only fetch if user is authenticated
  });

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);

    if (diffDays > 0) return `${diffDays}d`;
    if (diffHours > 0) return `${diffHours}h`;
    return "now";
  };

  const handleStoryClick = async (vibeId: string) => {
    setSelectedStory(vibeId);
    
    // Record view
    try {
      await fetch(`/api/daily-vibes/${vibeId}/view`, {
        method: "POST",
        credentials: "include"
      });
    } catch (error) {
      console.error("Failed to record story view:", error);
    }
  };

  // Show welcome screen for non-authenticated users
  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-vibe-purple via-vibe-pink to-vibe-orange">
        <div className="container mx-auto px-4 py-8">
          {/* Hero Section */}
          <div className="text-center py-20">
            <div className="max-w-4xl mx-auto">
              <h1 className="text-5xl lg:text-7xl font-bold text-white mb-6">
                Welcome to
                <span className="block bg-gradient-to-r from-yellow-200 to-pink-200 bg-clip-text text-transparent">
                  VibeVerse
                </span>
              </h1>
              
              <p className="text-xl lg:text-2xl text-white/90 mb-8 max-w-2xl mx-auto">
                The creator platform that's changing everything. Real monetization, authentic connections, 
                and genuine growth. Let's see if we can hit 80K paid users in 24 hours!
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
                <Link href="/register">
                  <Button 
                    size="lg" 
                    className="bg-white text-gray-900 hover:bg-white/90 px-8 py-4 text-lg font-semibold"
                    data-testid="button-get-started"
                  >
                    Get Started Free
                  </Button>
                </Link>
                <Link href="/auth">
                  <Button 
                    size="lg" 
                    variant="outline" 
                    className="bg-transparent border-white text-white hover:bg-white/10 px-8 py-4 text-lg font-semibold"
                    data-testid="button-sign-in"
                  >
                    Sign In
                  </Button>
                </Link>
              </div>

              {/* Features Preview */}
              <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
                <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white">
                  <CardContent className="pt-6 text-center">
                    <Crown className="w-12 h-12 mx-auto mb-4 text-yellow-300" />
                    <h3 className="text-xl font-semibold mb-2">Real Revenue</h3>
                    <p className="text-white/80">
                      Actual monetization through PayPal. No fake numbers, just real earnings for creators.
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white">
                  <CardContent className="pt-6 text-center">
                    <MessageCircle className="w-12 h-12 mx-auto mb-4 text-blue-300" />
                    <h3 className="text-xl font-semibold mb-2">Authentic Connections</h3>
                    <p className="text-white/80">
                      Direct messaging, voice calls, and real conversations. No bots, no fake engagement.
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white">
                  <CardContent className="pt-6 text-center">
                    <Video className="w-12 h-12 mx-auto mb-4 text-purple-300" />
                    <h3 className="text-xl font-semibold mb-2">Genuine Content</h3>
                    <p className="text-white/80">
                      24-hour stories that matter. Share real moments, build real communities.
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Challenge Banner */}
              <div className="bg-gradient-to-r from-yellow-400/20 to-orange-500/20 backdrop-blur-sm border border-yellow-400/30 rounded-2xl p-8 mt-16 max-w-2xl mx-auto">
                <div className="text-center">
                  <h2 className="text-2xl font-bold text-white mb-4">
                    🚀 The 80K Challenge
                  </h2>
                  <p className="text-lg text-white/90 mb-6">
                    Join the movement! We're aiming for 80,000 paid subscribers in the next 24 hours. 
                    Be part of the creator economy revolution.
                  </p>
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold text-yellow-300">LIVE NOW</div>
                      <div className="text-white/80 text-sm">Challenge Active</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-orange-300">80K GOAL</div>
                      <div className="text-white/80 text-sm">Paid Users Target</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (postsLoading || vibesLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center min-h-[400px]">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        
        {/* Post Creator */}
        {user && showPostCreator && (
          <div className="mb-8">
            <PostCreator 
              onClose={() => setShowPostCreator(false)}
              isOpen={showPostCreator}
            />
          </div>
        )}

        {/* Quick Actions for Authenticated Users */}
        {user && !showPostCreator && (
          <Card className="mb-8 bg-gradient-to-r from-vibe-purple/5 to-vibe-pink/5 border-vibe-purple/20">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={user.avatar || ""} alt="Your avatar" />
                    <AvatarFallback className="bg-vibe-purple text-white">
                      {user.username.slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-lg text-muted-foreground">What's on your mind, {user.username}?</p>
                  </div>
                </div>
                <Button
                  onClick={() => setShowPostCreator(true)}
                  className="bg-gradient-to-r from-vibe-purple to-vibe-pink hover:opacity-90"
                  data-testid="button-create-post"
                >
                  <Edit3 className="w-4 h-4 mr-2" />
                  Create Post
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
        
        {/* Stories Section */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-foreground mb-4">Daily Vibes</h2>
          <div className="flex space-x-4 overflow-x-auto pb-2" data-testid="stories-container">
            
            {/* Add Your Story - only show for authenticated users */}
            {user && (
              <div className="flex-shrink-0 text-center">
                <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mb-2 cursor-pointer hover:bg-muted/80 transition-colors">
                  <Plus className="w-6 h-6 text-muted-foreground" />
                </div>
                <span className="text-xs text-muted-foreground">Your Vibe</span>
              </div>
            )}
            
            {/* Story Items */}
            {dailyVibes.map((vibe) => (
              <div 
                key={vibe.id} 
                className="flex-shrink-0 text-center cursor-pointer"
                onClick={() => handleStoryClick(vibe.id)}
                data-testid={`story-${vibe.id}`}
              >
                <div className="w-16 h-16 rounded-full p-0.5 bg-gradient-to-r from-vibe-purple via-vibe-pink to-vibe-orange mb-2">
                  <div className="w-full h-full rounded-full bg-background flex items-center justify-center p-0.5">
                    {vibe.media.type === "image" ? (
                      <img 
                        src={vibe.media.url} 
                        alt="Story" 
                        className="w-full h-full rounded-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full rounded-full bg-muted flex items-center justify-center">
                        <Video className="w-6 h-6 text-muted-foreground" />
                      </div>
                    )}
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">creator_{vibe.creatorId.slice(-4)}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Feed Posts */}
        <div className="space-y-6">
          {posts.length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-12">
                  <div className="mb-4">
                    <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                      <Heart className="w-8 h-8 text-muted-foreground" />
                    </div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">Welcome to VibeVerse!</h3>
                    <p className="text-muted-foreground max-w-md mx-auto">
                      You're the first here! Create the very first post on VibeVerse and be part of the 80K Challenge history.
                    </p>
                  </div>
                  <div className="flex gap-4 justify-center">
                    <Button 
                      onClick={() => setShowPostCreator(true)}
                      className="bg-gradient-to-r from-vibe-purple to-vibe-pink"
                    >
                      Create First Post
                    </Button>
                    <Link href="/find-friends">
                      <Button variant="outline">Find Friends</Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            posts.map((post) => (
              <Card key={post.id} className="overflow-hidden" data-testid={`post-${post.id}`}>
                
                {/* Post Header */}
                <div className="flex items-center justify-between p-4">
                  <div className="flex items-center">
                    <Avatar className="h-10 w-10 mr-3">
                      <AvatarImage src="" alt="Creator avatar" />
                      <AvatarFallback>
                        {post.creatorId.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center">
                        <span className="font-semibold text-foreground">
                          creator_{post.creatorId.slice(-8)}
                        </span>
                        {post.visibility === "premium" && (
                          <Crown className="w-4 h-4 text-vibe-purple ml-1" />
                        )}
                      </div>
                      <span className="text-sm text-muted-foreground">
                        {formatTimeAgo(post.createdAt)}
                      </span>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M10 6a2 2 0 110-4 2 2 0 010 4zM10 12a2 2 0 110-4 2 2 0 010 4zM10 18a2 2 0 110-4 2 2 0 010 4z" />
                    </svg>
                  </Button>
                </div>

                {/* Post Content */}
                <div className="px-4 pb-3">
                  <p className="text-foreground mb-3">{post.body}</p>
                  {post.visibility === "premium" && (
                    <div className="bg-gradient-to-r from-vibe-purple/10 to-vibe-pink/10 p-3 rounded-xl border border-vibe-purple/20 mb-3">
                      <div className="flex items-center text-sm text-vibe-purple font-medium">
                        <Crown className="w-4 h-4 mr-2" />
                        Premium Content - Subscribe to View
                      </div>
                    </div>
                  )}
                </div>

                {/* Post Media */}
                {post.media.length > 0 && post.visibility === "public" && (
                  <div className="mb-4">
                    {post.media[0].type === "image" ? (
                      <img 
                        src={post.media[0].url} 
                        alt={post.media[0].alt || "Post image"} 
                        className="w-full max-h-96 object-cover"
                      />
                    ) : (
                      <div className="w-full h-64 bg-muted flex items-center justify-center">
                        <Video className="w-12 h-12 text-muted-foreground" />
                      </div>
                    )}
                  </div>
                )}

                {/* Post Actions */}
                <div className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-4">
                      <Button variant="ghost" size="sm" className="p-0 h-auto">
                        <Heart className="w-5 h-5 mr-2" />
                        <span className="text-sm">{post.stats.likes}</span>
                      </Button>
                      <Button variant="ghost" size="sm" className="p-0 h-auto">
                        <MessageCircle className="w-5 h-5 mr-2" />
                        <span className="text-sm">{post.stats.comments}</span>
                      </Button>
                      <Button variant="ghost" size="sm" className="p-0 h-auto">
                        <Share2 className="w-5 h-5 mr-2" />
                        <span className="text-sm">{post.stats.shares}</span>
                      </Button>
                    </div>
                    <Button variant="ghost" size="sm" className="p-0 h-auto">
                      <Bookmark className="w-5 h-5" />
                    </Button>
                  </div>
                  
                  {/* Engagement Actions */}
                  {post.stats.comments > 0 && (
                    <div className="text-sm text-muted-foreground">
                      <Button variant="ghost" size="sm" className="p-0 h-auto text-muted-foreground">
                        View all {post.stats.comments} comments
                      </Button>
                    </div>
                  )}
                </div>
              </Card>
            ))
          )}
        </div>

        {/* 80K Challenge CTA */}
        {!user?.subscription?.plan && (
          <Card className="mt-8 bg-gradient-to-r from-orange-500/10 to-yellow-500/10 border-orange-500/30">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-4xl mb-4">🚀</div>
                <h3 className="text-xl font-bold text-foreground mb-2">
                  Join the 80K Challenge
                </h3>
                <p className="text-muted-foreground mb-4">
                  Be part of the movement to reach 80,000 paid users in 24 hours. Real platform, real growth, real opportunity.
                </p>
                <div className="flex gap-4 justify-center mb-4">
                  <Badge variant="outline" className="border-orange-500 text-orange-700">
                    Basic - £7.99/mo
                  </Badge>
                  <Badge className="bg-gradient-to-r from-orange-500 to-yellow-500 text-white">
                    Creator - £19.99/mo
                  </Badge>
                </div>
                <Link href="/register">
                  <Button className="bg-gradient-to-r from-orange-500 to-yellow-500 text-white hover:opacity-90">
                    Join the Challenge Now
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        )}

      </div>

      {/* Story Modal (if selectedStory) */}
      {selectedStory && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center"
          onClick={() => setSelectedStory(null)}
        >
          <div className="relative max-w-sm w-full mx-4">
            <div className="bg-black rounded-2xl overflow-hidden">
              {/* Story progress bar */}
              <div className="w-full bg-gray-600 h-1">
                <div className="bg-white h-1 w-full animate-pulse"></div>
              </div>
              
              {/* Story content */}
              <div className="aspect-[9/16] bg-gradient-to-br from-vibe-purple to-vibe-pink flex items-center justify-center">
                <div className="text-white text-center">
                  <div className="text-4xl mb-4">🎨</div>
                  <p className="text-lg">Daily Vibe Story</p>
                  <p className="text-sm opacity-80">Tap to close</p>
                </div>
              </div>
            </div>
            
            <Button
              onClick={() => setSelectedStory(null)}
              className="absolute top-4 right-4 bg-black/50 text-white rounded-full w-8 h-8 p-0"
            >
              ×
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
