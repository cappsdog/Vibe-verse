import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Phone, Video, Paperclip, Send, Smile, Search, MoreVertical } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

interface Message {
  id: string;
  threadId: string;
  senderId: string;
  recipientId: string;
  body?: string;
  media: Array<{ type: string; url: string; size?: number }>;
  kind: string;
  readAt: Array<{ userId: string; readAt: string }>;
  createdAt: string;
}

interface Conversation {
  threadId: string;
  lastMessage: Message;
  unreadCount: number;
}

export default function MessagesPage() {
  const { user } = useAuth();
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [messageText, setMessageText] = useState("");
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [isTyping, setIsTyping] = useState<Record<string, boolean>>({});
  const [onlineUsers, setOnlineUsers] = useState<Set<string>>(new Set());
  const [activeCall, setActiveCall] = useState<{ type: 'voice' | 'video'; userId: string } | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: conversations = [], isLoading: conversationsLoading, refetch: refetchConversations } = useQuery<Conversation[]>({
    queryKey: ["/api/messages/conversations"],
  });

  const { data: messages = [], refetch: refetchMessages } = useQuery<Message[]>({
    queryKey: ["/api/messages", selectedConversation],
    queryFn: () => selectedConversation ? 
      fetch(`/api/messages/${selectedConversation}`, { credentials: 'include' }).then(res => res.json()) : 
      Promise.resolve([]),
    enabled: !!selectedConversation,
  });

  // WebSocket connection for real-time messaging
  useEffect(() => {
    if (!user) return;

    const connectWebSocket = async () => {
      try {
        // Get WebSocket token
        const tokenResponse = await fetch("/api/ws-token", {
          credentials: "include"
        });
        
        if (!tokenResponse.ok) {
          console.log("WebSocket token not available - using polling fallback");
          return;
        }
        
        const { token } = await tokenResponse.json();

        // Connect to WebSocket
        const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
        const wsUrl = `${protocol}//${window.location.host}/ws?token=${token}`;
        const ws = new WebSocket(wsUrl);

        ws.onopen = () => {
          console.log("WebSocket connected");
          setSocket(ws);
        };

        ws.onmessage = (event) => {
          const data = JSON.parse(event.data);
          handleWebSocketMessage(data);
        };

        ws.onclose = () => {
          console.log("WebSocket disconnected");
          setSocket(null);
          // Attempt reconnection after 3 seconds
          setTimeout(connectWebSocket, 3000);
        };

        ws.onerror = (error) => {
          console.error("WebSocket error:", error);
        };

      } catch (error) {
        console.error("Failed to connect WebSocket:", error);
      }
    };

    connectWebSocket();

    return () => {
      if (socket) {
        socket.close();
        setSocket(null);
      }
    };
  }, [user]);

  const handleWebSocketMessage = (data: any) => {
    switch (data.type) {
      case 'new_message':
        refetchMessages();
        refetchConversations();
        break;
      case 'typing':
        setIsTyping(prev => ({ ...prev, [data.userId]: true }));
        setTimeout(() => {
          setIsTyping(prev => ({ ...prev, [data.userId]: false }));
        }, 3000);
        break;
      case 'user_online':
        setOnlineUsers(prev => new Set(prev).add(data.userId));
        break;
      case 'user_offline':
        setOnlineUsers(prev => {
          const newSet = new Set(prev);
          newSet.delete(data.userId);
          return newSet;
        });
        break;
    }
  };

  const sendMessage = async () => {
    if (!messageText.trim() || !selectedConversation) return;

    try {
      const response = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          threadId: selectedConversation,
          body: messageText,
          kind: 'text'
        })
      });

      if (response.ok) {
        setMessageText('');
        refetchMessages();
        refetchConversations();
        
        // Send via WebSocket for real-time updates
        if (socket && socket.readyState === WebSocket.OPEN) {
          socket.send(JSON.stringify({
            type: 'send_message',
            threadId: selectedConversation,
            body: messageText
          }));
        }
      }
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  const startCall = (type: 'voice' | 'video') => {
    if (!selectedConversation) return;
    
    const recipientId = selectedConversation.replace(user?.id || '', '').replace('_', '');
    setActiveCall({ type, userId: recipientId });
    
    // In a real implementation, this would initiate WebRTC connection
    // For now, we'll show a mock call interface
  };

  const endCall = () => {
    setActiveCall(null);
  };

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Please sign in</h2>
          <p className="text-muted-foreground">You need to be signed in to access messages.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex bg-background">
      {/* Sidebar - Conversations List */}
      <div className="w-1/3 border-r border-border flex flex-col">
        <div className="p-4 border-b border-border">
          <h1 className="text-xl font-semibold mb-4">Messages</h1>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search conversations..."
              className="pl-10"
              data-testid="search-conversations"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {conversationsLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : conversations.length > 0 ? (
            conversations.map((conv) => (
              <div
                key={conv.threadId}
                className={`p-4 border-b border-border cursor-pointer hover:bg-muted/50 transition-colors ${
                  selectedConversation === conv.threadId ? 'bg-muted' : ''
                }`}
                onClick={() => setSelectedConversation(conv.threadId)}
                data-testid={`conversation-${conv.threadId}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src="" alt="User" />
                      <AvatarFallback>
                        {conv.threadId.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="font-medium text-foreground truncate">
                          User {conv.threadId.slice(-4)}
                        </p>
                        <span className="text-xs text-muted-foreground">
                          {new Date(conv.lastMessage.createdAt).toLocaleTimeString([], { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                          })}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground truncate">
                        {conv.lastMessage.body || 'Media message'}
                      </p>
                    </div>
                  </div>
                  {conv.unreadCount > 0 && (
                    <Badge className="bg-primary text-primary-foreground">
                      {conv.unreadCount}
                    </Badge>
                  )}
                </div>
              </div>
            ))
          ) : (
            <div className="flex items-center justify-center py-12 px-4">
              <div className="text-center">
                <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                  <Send className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="font-semibold mb-2">No conversations yet</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Start a conversation by finding friends and sending them a message.
                </p>
                <Button variant="outline" size="sm">
                  Find Friends
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {selectedConversation ? (
          <>
            {/* Chat Header */}
            <div className="p-4 border-b border-border flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Avatar className="h-10 w-10">
                  <AvatarImage src="" alt="User" />
                  <AvatarFallback>
                    {selectedConversation.slice(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h2 className="font-semibold">User {selectedConversation.slice(-4)}</h2>
                  <p className="text-sm text-muted-foreground">
                    {onlineUsers.has(selectedConversation) ? 'Online' : 'Last seen recently'}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => startCall('voice')}
                  data-testid="voice-call-button"
                >
                  <Phone className="w-4 h-4" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => startCall('video')}
                  data-testid="video-call-button"
                >
                  <Video className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.senderId === user.id ? 'justify-end' : 'justify-start'}`}
                  data-testid={`message-${message.id}`}
                >
                  <div
                    className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                      message.senderId === user.id
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted text-foreground'
                    }`}
                  >
                    <p className="text-sm">{message.body}</p>
                    <p className="text-xs opacity-70 mt-1">
                      {new Date(message.createdAt).toLocaleTimeString([], { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </p>
                  </div>
                </div>
              ))}
              
              {/* Typing indicator */}
              {Object.keys(isTyping).some(userId => isTyping[userId]) && (
                <div className="flex justify-start">
                  <div className="bg-muted px-4 py-2 rounded-lg">
                    <p className="text-sm text-muted-foreground">
                      Typing<span className="animate-pulse">...</span>
                    </p>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input */}
            <div className="p-4 border-t border-border">
              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="sm">
                  <Paperclip className="w-4 h-4" />
                </Button>
                <Input
                  placeholder="Type a message..."
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      sendMessage();
                    }
                  }}
                  className="flex-1"
                  data-testid="message-input"
                />
                <Button variant="ghost" size="sm">
                  <Smile className="w-4 h-4" />
                </Button>
                <Button 
                  onClick={sendMessage} 
                  disabled={!messageText.trim()}
                  data-testid="send-message-button"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <Send className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Select a conversation</h3>
              <p className="text-muted-foreground">
                Choose a conversation from the sidebar to start messaging.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Active Call Modal */}
      {activeCall && (
        <div className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center">
          <div className="bg-background rounded-lg p-8 max-w-md w-full mx-4">
            <div className="text-center">
              <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                {activeCall.type === 'video' ? (
                  <Video className="w-12 h-12 text-muted-foreground" />
                ) : (
                  <Phone className="w-12 h-12 text-muted-foreground" />
                )}
              </div>
              <h3 className="text-xl font-semibold mb-2">
                {activeCall.type === 'video' ? 'Video Call' : 'Voice Call'}
              </h3>
              <p className="text-muted-foreground mb-6">
                Calling User {activeCall.userId.slice(-4)}...
              </p>
              
              {activeCall.type === 'video' && (
                <div className="bg-black rounded-lg aspect-video mb-6 flex items-center justify-center">
                  <p className="text-white">Video call would appear here</p>
                </div>
              )}
              
              <div className="flex justify-center space-x-4">
                <Button 
                  variant="destructive" 
                  onClick={endCall}
                  className="rounded-full w-12 h-12 p-0"
                  data-testid="end-call-button"
                >
                  <Phone className="w-5 h-5 rotate-45" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}