import { useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, ArrowRight } from "lucide-react";

export default function PaymentSuccessPage() {
  const [location] = useLocation();
  const urlParams = new URLSearchParams(location.split('?')[1] || '');
  const welcome = urlParams.get('welcome');

  useEffect(() => {
    // Handle subscription confirmation
    const urlParams = new URLSearchParams(location.split('?')[1] || '');
    const subscriptionId = urlParams.get('subscription_id');
    const pendingPayment = sessionStorage.getItem('pendingPayment');
    
    if (subscriptionId && pendingPayment) {
      const paymentData = JSON.parse(pendingPayment);
      
      // Confirm the subscription activation
      fetch('/api/paypal/subscription/confirm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          subscriptionId: subscriptionId,
          plan: paymentData.plan,
          userId: paymentData.userId
        })
      }).then(response => {
        if (response.ok) {
          // Clear the pending payment
          sessionStorage.removeItem('pendingPayment');
          
          // Refresh user data by forcing a page reload after 3 seconds
          setTimeout(() => {
            window.location.href = '/';
          }, 3000);
        }
      }).catch(error => {
        console.error('Failed to confirm subscription:', error);
      });
    } else {
      // Clear any pending payment data
      sessionStorage.removeItem('pendingPayment');
    }
  }, [location]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-vibe-purple via-vibe-pink to-vibe-orange">
      <div className="container mx-auto px-4 py-8 flex items-center justify-center min-h-screen">
        <Card className="w-full max-w-md bg-white/95 backdrop-blur-sm border-0 shadow-2xl">
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <CardTitle className="text-2xl font-bold text-gray-900">
              Payment Successful!
            </CardTitle>
          </CardHeader>
          
          <CardContent className="text-center space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Welcome to VibeVerse!
              </h3>
              <p className="text-gray-600">
                Your subscription has been activated and you're now part of the 80K Challenge movement.
              </p>
            </div>

            <div className="bg-gradient-to-r from-green-50 to-blue-50 p-4 rounded-lg">
              <p className="text-sm text-gray-700">
                🚀 <strong>80K Challenge Progress:</strong><br />
                You've joined thousands of others working toward 80,000 paid users in 24 hours!
              </p>
            </div>

            <div className="space-y-4">
              <Link href="/">
                <Button 
                  className="w-full bg-gradient-to-r from-vibe-purple to-vibe-pink hover:opacity-90"
                  data-testid="button-get-started"
                >
                  Start Creating
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
              
              <p className="text-sm text-gray-500">
                You can now create posts, send messages, and access all premium features!
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}