import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Star, Check, Crown, Zap, CreditCard } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function PlanSelectionPage() {
  const { user, registerMutation } = useAuth();
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState<"free" | "basic" | "creator">("free");
  const [step, setStep] = useState<"plans" | "register" | "payment">("plans");
  const [registerData, setRegisterData] = useState({ 
    email: "", 
    username: "", 
    password: "", 
    confirmPassword: "" 
  });
  const [paypalLoaded, setPaypalLoaded] = useState(false);
  const [paymentProcessing, setPaymentProcessing] = useState(false);
  const [newUserId, setNewUserId] = useState<string | null>(null);

  const plans = [
    {
      id: "free" as const,
      name: "Free",
      price: "£0",
      period: "forever",
      icon: Star,
      color: "from-gray-500 to-gray-600",
      borderColor: "border-gray-300",
      features: [
        "Browse and discover content",
        "Follow creators",
        "Basic messaging",
        "View Daily Vibes",
        "Limited creator interactions"
      ]
    },
    {
      id: "basic" as const,
      name: "Basic",
      price: "£7.99",
      period: "month",
      icon: Check,
      color: "from-blue-500 to-blue-600",
      borderColor: "border-blue-300",
      popular: false,
      features: [
        "Everything in Free",
        "Unlimited messaging",
        "Voice & video calls",
        "Premium creator content access",
        "Priority customer support",
        "Ad-free experience"
      ]
    },
    {
      id: "creator" as const,
      name: "Creator",
      price: "£19.99",
      period: "month",
      icon: Crown,
      color: "from-purple-500 to-pink-500",
      borderColor: "border-purple-300",
      popular: true,
      features: [
        "Everything in Basic",
        "Create and monetize content",
        "Daily Vibes stories",
        "Premium fan subscriptions",
        "Analytics dashboard",
        "Creator payouts",
        "Advanced creator tools"
      ]
    }
  ];

  const handlePlanSelect = (plan: "free" | "basic" | "creator") => {
    setSelectedPlan(plan);
    if (plan === "free") {
      // Free plan can register immediately
      setStep("register");
    } else {
      // Paid plans need payment setup
      setStep("register");
    }
  };

  // Load PayPal SDK
  useEffect(() => {
    if (step === "payment" && selectedPlan !== "free") {
      const script = document.createElement("script");
      script.src = `https://www.paypal.com/sdk/js?client-id=${import.meta.env.VITE_PAYPAL_CLIENT_ID}&currency=GBP&intent=capture`;
      script.async = true;
      script.onload = () => setPaypalLoaded(true);
      document.body.appendChild(script);

      return () => {
        document.body.removeChild(script);
      };
    }
  }, [step, selectedPlan]);

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (registerData.password !== registerData.confirmPassword) {
      return;
    }
    
    registerMutation.mutate({
      email: registerData.email,
      username: registerData.username,
      password: registerData.password,
      role: selectedPlan === "creator" ? "creator" : "user",
      isCreator: selectedPlan === "creator",
      subscription: {
        plan: selectedPlan,
        status: selectedPlan === "free" ? "active" : "pending"
      }
    }, {
      onSuccess: (userData) => {
        setNewUserId(userData.id);
        if (selectedPlan === "free") {
          toast({
            title: "Welcome to VibeVerse!",
            description: "Your free account has been created successfully.",
          });
          // Will redirect automatically due to user state change
        } else {
          // For paid plans, go to payment without signing in
          setStep("payment");
        }
      },
      onError: (error) => {
        toast({
          title: "Registration Failed",
          description: error.message || "Failed to create account. Please try again.",
          variant: "destructive",
        });
      }
    });
  };

  const handlePayPalPayment = async () => {
    setPaymentProcessing(true);

    try {
      // Store payment info for completion after PayPal redirect
      sessionStorage.setItem('pendingPayment', JSON.stringify({
        userId: newUserId,
        plan: selectedPlan
      }));

      // Create PayPal subscription using live credentials
      const subscriptionResponse = await fetch('/api/paypal/subscription/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          plan: selectedPlan,
          userId: newUserId
        })
      });

      const subscriptionData = await subscriptionResponse.json();

      if (!subscriptionResponse.ok) {
        throw new Error(subscriptionData.error || 'Failed to create PayPal subscription');
      }

      // Get PayPal approval URL and force login by clearing all PayPal cookies
      const approvalUrl = subscriptionData.links?.find((link: any) => link.rel === 'approve')?.href;
      
      if (approvalUrl) {
        console.log('PayPal subscription URL:', approvalUrl);
        
        // Method 1: Clear all possible PayPal session data
        localStorage.clear();
        sessionStorage.clear();
        
        // Method 2: Use PayPal logout to clear cookies before redirecting
        const logoutFrame = document.createElement('iframe');
        logoutFrame.style.display = 'none';
        logoutFrame.src = 'https://www.paypal.com/signin/logout';
        document.body.appendChild(logoutFrame);
        
        // Method 3: Force logout and open incognito-like behavior
        setTimeout(() => {
          document.body.removeChild(logoutFrame);
          
          // Final solution: Open PayPal in a new window that forces login
          const paypalWindow = window.open('', 'paypal_login', 'width=800,height=600,scrollbars=yes,resizable=yes');
          if (paypalWindow) {
            // Write a page that will redirect to PayPal with forced logout
            paypalWindow.document.write(`
              <html>
                <head><title>Redirecting to PayPal...</title></head>
                <body>
                  <p>Redirecting you to PayPal login...</p>
                  <script>
                    // First logout, then redirect to subscription
                    fetch('https://www.paypal.com/signin/logout', {mode: 'no-cors'}).then(() => {
                      window.location.href = '${approvalUrl}';
                    }).catch(() => {
                      window.location.href = '${approvalUrl}';
                    });
                  </script>
                </body>
              </html>
            `);
            paypalWindow.document.close();
          } else {
            // Fallback: direct redirect with cache busting
            const urlWithBust = new URL(approvalUrl);
            urlWithBust.searchParams.set('_t', Date.now().toString());
            window.location.href = urlWithBust.toString();
          }
        }, 1000);
        
      } else {
        throw new Error('No PayPal approval URL found');
      }

    } catch (error) {
      console.error('PayPal subscription error:', error);
      toast({
        title: "Payment Failed",
        description: error instanceof Error ? error.message : "Failed to process payment",
        variant: "destructive",
      });
      setPaymentProcessing(false);
    }
  };

  // Redirect if already logged in
  if (user) {
    return <Redirect to="/" />;
  }

  if (step === "payment") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-vibe-purple via-vibe-pink to-vibe-orange">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-md mx-auto">
            {/* Plan Summary */}
            <Card className="mb-6 bg-white/95 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader className="text-center">
                <CardTitle className="flex items-center justify-center gap-2">
                  {(() => {
                    const PlanIcon = plans.find(p => p.id === selectedPlan)?.icon || Star;
                    return <PlanIcon className="w-5 h-5" />;
                  })()}
                  {plans.find(p => p.id === selectedPlan)?.name} Plan
                </CardTitle>
                <CardDescription>
                  {plans.find(p => p.id === selectedPlan)?.price}/${plans.find(p => p.id === selectedPlan)?.period}
                </CardDescription>
              </CardHeader>
            </Card>

            {/* Payment Form */}
            <Card className="bg-white/95 backdrop-blur-sm border-0 shadow-2xl">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl font-bold text-gray-900">
                  Complete Your Payment
                </CardTitle>
                <CardDescription className="text-gray-600">
                  Join the 80K Challenge! Pay securely with PayPal and be part of the movement.
                </CardDescription>
              </CardHeader>
              
              <CardContent className="space-y-6">
                {/* Payment Summary */}
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-600">{plans.find(p => p.id === selectedPlan)?.name} Plan</span>
                    <span className="font-semibold">{plans.find(p => p.id === selectedPlan)?.price}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm text-gray-500">
                    <span>Billed monthly</span>
                    <span>GBP</span>
                  </div>
                  <hr className="my-3" />
                  <div className="flex justify-between items-center font-bold text-lg">
                    <span>Total</span>
                    <span>{plans.find(p => p.id === selectedPlan)?.price}</span>
                  </div>
                </div>

                {/* PayPal Payment */}
                <div className="space-y-4">
                  <Button
                    onClick={handlePayPalPayment}
                    disabled={paymentProcessing || !paypalLoaded}
                    className="w-full bg-[#0070ba] hover:bg-[#005ea6] text-white py-3 text-lg font-semibold"
                    data-testid="button-paypal-payment"
                  >
                    {paymentProcessing ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Processing...
                      </>
                    ) : !paypalLoaded ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Loading PayPal...
                      </>
                    ) : (
                      <>
                        <CreditCard className="mr-2 h-5 w-5" />
                        Pay with PayPal
                      </>
                    )}
                  </Button>

                  <div className="text-center">
                    <p className="text-sm text-gray-500">
                      You'll be redirected to PayPal to complete your payment securely
                    </p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setStep("register")}
                    className="flex-1"
                    data-testid="button-back-to-register"
                  >
                    Back
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  if (step === "register") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-vibe-purple via-vibe-pink to-vibe-orange">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-md mx-auto">
            {/* Plan Summary */}
            <Card className="mb-6 bg-white/95 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader className="text-center">
                <CardTitle className="flex items-center justify-center gap-2">
                  {(() => {
                    const PlanIcon = plans.find(p => p.id === selectedPlan)?.icon || Star;
                    return <PlanIcon className="w-5 h-5" />;
                  })()}
                  {plans.find(p => p.id === selectedPlan)?.name} Plan
                </CardTitle>
                <CardDescription>
                  {selectedPlan === "free" ? "Free forever" : `${plans.find(p => p.id === selectedPlan)?.price}/${plans.find(p => p.id === selectedPlan)?.period}`}
                </CardDescription>
              </CardHeader>
            </Card>

            {/* Registration Form */}
            <Card className="bg-white/95 backdrop-blur-sm border-0 shadow-2xl">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl font-bold text-gray-900">
                  Create Your Account
                </CardTitle>
                <CardDescription className="text-gray-600">
                  Join VibeVerse and start your journey
                </CardDescription>
              </CardHeader>
              
              <CardContent>
                <form onSubmit={handleRegister} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="register-email">Email</Label>
                    <Input
                      id="register-email"
                      data-testid="input-register-email"
                      type="email"
                      value={registerData.email}
                      onChange={(e) => setRegisterData({...registerData, email: e.target.value})}
                      placeholder="Enter your email"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="register-username">Username</Label>
                    <Input
                      id="register-username"
                      data-testid="input-register-username"
                      type="text"
                      value={registerData.username}
                      onChange={(e) => setRegisterData({...registerData, username: e.target.value})}
                      placeholder="Choose a username"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="register-password">Password</Label>
                    <Input
                      id="register-password"
                      data-testid="input-register-password"
                      type="password"
                      value={registerData.password}
                      onChange={(e) => setRegisterData({...registerData, password: e.target.value})}
                      placeholder="Create a password"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="register-confirm-password">Confirm Password</Label>
                    <Input
                      id="register-confirm-password"
                      data-testid="input-register-confirm-password"
                      type="password"
                      value={registerData.confirmPassword}
                      onChange={(e) => setRegisterData({...registerData, confirmPassword: e.target.value})}
                      placeholder="Confirm your password"
                      required
                    />
                  </div>
                  
                  <div className="flex gap-3">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setStep("plans")}
                      className="flex-1"
                      data-testid="button-back-to-plans"
                    >
                      Back to Plans
                    </Button>
                    <Button
                      type="submit"
                      data-testid="button-register-submit"
                      className={`flex-1 bg-gradient-to-r ${plans.find(p => p.id === selectedPlan)?.color} hover:opacity-90`}
                      disabled={registerMutation.isPending || registerData.password !== registerData.confirmPassword}
                    >
                      {registerMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Creating Account...
                        </>
                      ) : (
                        selectedPlan === "free" ? "Join Free" : "Continue to Payment"
                      )}
                    </Button>
                  </div>
                  
                  {registerData.password !== registerData.confirmPassword && registerData.confirmPassword && (
                    <p className="text-sm text-red-500">Passwords do not match</p>
                  )}
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-vibe-purple via-vibe-pink to-vibe-orange">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-6">
            <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center mr-4">
              <Star className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-white">VibeVerse</h1>
          </div>
          
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
            Choose Your Plan
          </h2>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            Start your creator journey or enjoy unlimited content access. 
            Upgrade anytime as your needs grow.
          </p>
        </div>

        {/* Plans Grid */}
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto mb-8">
          {plans.map((plan) => (
            <Card 
              key={plan.id}
              className={`relative bg-white/95 backdrop-blur-sm border-2 shadow-xl transition-all duration-200 hover:scale-105 cursor-pointer ${
                selectedPlan === plan.id ? plan.borderColor : 'border-white/30'
              } ${plan.popular ? 'ring-2 ring-yellow-400' : ''}`}
              onClick={() => setSelectedPlan(plan.id)}
              data-testid={`plan-card-${plan.id}`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <div className="bg-gradient-to-r from-yellow-400 to-orange-400 text-black px-4 py-1 rounded-full text-sm font-bold">
                    Most Popular
                  </div>
                </div>
              )}
              
              <CardHeader className="text-center">
                <div className={`inline-flex p-3 rounded-2xl bg-gradient-to-r ${plan.color} mb-4`}>
                  <plan.icon className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
                <CardDescription className="text-3xl font-bold text-gray-900">
                  {plan.price}
                  {plan.id !== "free" && <span className="text-lg font-normal text-gray-600">/{plan.period}</span>}
                </CardDescription>
              </CardHeader>
              
              <CardContent>
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Button
                  className={`w-full bg-gradient-to-r ${plan.color} hover:opacity-90 text-white`}
                  onClick={() => handlePlanSelect(plan.id)}
                  data-testid={`button-select-${plan.id}`}
                >
                  {selectedPlan === plan.id ? (
                    <>
                      <Check className="mr-2 h-4 w-4" />
                      Selected
                    </>
                  ) : (
                    plan.id === "free" ? "Start Free" : "Choose Plan"
                  )}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Continue Button */}
        <div className="text-center">
          <Button
            size="lg"
            className="bg-white text-gray-900 hover:bg-white/90 px-8 py-3 text-lg font-semibold"
            onClick={() => setStep("register")}
            disabled={!selectedPlan}
            data-testid="button-continue-to-register"
          >
            Continue with {plans.find(p => p.id === selectedPlan)?.name} Plan
            <Zap className="ml-2 h-5 w-5" />
          </Button>
        </div>

        {/* Login Link */}
        <div className="text-center mt-8">
          <p className="text-white/80">
            Already have an account?{" "}
            <a href="/auth" className="text-white font-semibold hover:underline">
              Sign in here
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}