import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { createPaypalOrder, capturePaypalOrder, loadPaypalDefault } from "./paypal";
import { setupWebSocket } from "./socket";
import { storage } from "./storage";
import { insertDailyVibeSchema, insertPostSchema, insertReportSchema } from "@shared/schema";
import jwt from "jsonwebtoken";

// Middleware to authenticate API requests
const authenticateToken = async (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.sendStatus(401);
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as { userId: string };
    const user = await storage.getUser(decoded.userId);
    if (!user) {
      return res.sendStatus(401);
    }
    req.user = user;
    next();
  } catch (error) {
    return res.sendStatus(403);
  }
};

// Middleware to check if user is creator
const requireCreator = async (req: any, res: any, next: any) => {
  if (!req.user || !req.user.isCreator) {
    return res.status(403).json({ error: "Creator access required" });
  }
  next();
};

// Middleware to check if user is admin
const requireAdmin = async (req: any, res: any, next: any) => {
  if (!req.user || req.user.role !== "admin") {
    return res.status(403).json({ error: "Admin access required" });
  }
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  setupAuth(app);

  // PayPal routes
  app.get("/api/paypal/setup", async (req, res) => {
    await loadPaypalDefault(req, res);
  });

  app.post("/api/paypal/order", async (req, res) => {
    await createPaypalOrder(req, res);
  });

  app.post("/api/paypal/order/:orderID/capture", async (req, res) => {
    await capturePaypalOrder(req, res);
  });

  // PayPal subscription routes for connecting to james.cappps@hotmail.com
  app.post("/api/paypal/subscription", authenticateToken, async (req, res) => {
    try {
      const { plan, paypalOrderId } = req.body;
      
      if (!req.user) return res.sendStatus(401);
      
      // Update user subscription with PayPal info
      const updatedUser = await storage.updateUser(req.user.id, {
        subscription: {
          plan,
          status: "active",
          paypalSubscriptionId: paypalOrderId,
          currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days
        }
      });
      
      res.json({ success: true, user: updatedUser });
    } catch (error) {
      console.error("Subscription update error:", error);
      res.status(500).json({ error: "Failed to update subscription" });
    }
  });

  // PayPal subscription creation
  app.post("/api/paypal/subscription/create", async (req, res) => {
    try {
      const { plan, userId } = req.body;
      
      // First, let's create the subscription plans if they don't exist
      const planIds = {
        basic: process.env.PLAN_BASIC_ID,
        creator: process.env.PLAN_PRO_ID
      };
      
      // If plan IDs aren't set, create them dynamically
      if (!planIds.basic || !planIds.creator) {
        const accessToken = await getPayPalAccessToken();
        
        // Create product first
        const productResponse = await fetch('https://api-m.paypal.com/v1/catalogs/products', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`,
            'PayPal-Request-Id': `vibeverse-product-${Date.now()}`
          },
          body: JSON.stringify({
            name: "VibeVerse Memberships",
            description: "VibeVerse subscription plans for creators and fans",
            type: "SERVICE",
            category: "SOFTWARE"
          })
        });
        
        const product = await productResponse.json();
        
        if (productResponse.ok) {
          // Create Basic Plan (£7.99/month)
          const basicPlanResponse = await fetch('https://api-m.paypal.com/v1/billing/plans', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${accessToken}`,
              'PayPal-Request-Id': `vibeverse-basic-${Date.now()}`
            },
            body: JSON.stringify({
              product_id: product.id,
              name: "VibeVerse Basic Plan",
              description: "£7.99/month subscription to VibeVerse",
              billing_cycles: [{
                frequency: {
                  interval_unit: "MONTH",
                  interval_count: 1
                },
                tenure_type: "REGULAR",
                sequence: 1,
                total_cycles: 0,
                pricing_scheme: {
                  fixed_price: {
                    value: "7.99",
                    currency_code: "GBP"
                  }
                }
              }],
              payment_preferences: {
                auto_bill_outstanding: true,
                setup_fee_failure_action: "CONTINUE",
                payment_failure_threshold: 3
              }
            })
          });
          
          // Create Creator Plan (£19.99/month)
          const creatorPlanResponse = await fetch('https://api-m.paypal.com/v1/billing/plans', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${accessToken}`,
              'PayPal-Request-Id': `vibeverse-creator-${Date.now()}`
            },
            body: JSON.stringify({
              product_id: product.id,
              name: "VibeVerse Creator Plan",
              description: "£19.99/month subscription to VibeVerse Creator features",
              billing_cycles: [{
                frequency: {
                  interval_unit: "MONTH",
                  interval_count: 1
                },
                tenure_type: "REGULAR",
                sequence: 1,
                total_cycles: 0,
                pricing_scheme: {
                  fixed_price: {
                    value: "19.99",
                    currency_code: "GBP"
                  }
                }
              }],
              payment_preferences: {
                auto_bill_outstanding: true,
                setup_fee_failure_action: "CONTINUE",
                payment_failure_threshold: 3
              }
            })
          });
          
          const basicPlan = await basicPlanResponse.json();
          const creatorPlan = await creatorPlanResponse.json();
          
          if (basicPlanResponse.ok && creatorPlanResponse.ok) {
            console.log('Created PayPal plans:', {
              basic: basicPlan.id,
              creator: creatorPlan.id
            });
            
            planIds.basic = basicPlan.id;
            planIds.creator = creatorPlan.id;
          }
        }
      }
      
      const planId = planIds[plan as keyof typeof planIds];
      if (!planId) {
        return res.status(400).json({ error: 'Plan not available. Please try again.' });
      }

      // Create subscription with PayPal - force login by not allowing guest checkout
      const subscriptionData = {
        plan_id: planId,
        application_context: {
          brand_name: "VibeVerse",
          locale: "en-GB", 
          user_action: "SUBSCRIBE_NOW",
          shipping_preference: "NO_SHIPPING",
          return_url: `${process.env.NODE_ENV === 'production' ? 'https' : 'http'}://${process.env.REPLIT_DOMAINS?.split(',')[0] || 'localhost:5000'}/api/paypal/subscription/success`,
          cancel_url: `${process.env.NODE_ENV === 'production' ? 'https' : 'http'}://${process.env.REPLIT_DOMAINS?.split(',')[0] || 'localhost:5000'}/api/paypal/cancel`
        }
      };

      const response = await fetch('https://api-m.paypal.com/v1/billing/subscriptions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${await getPayPalAccessToken()}`,
          'Accept': 'application/json',
          'PayPal-Request-Id': `vibeverse-${Date.now()}-${userId}`
        },
        body: JSON.stringify(subscriptionData)
      });

      const subscription = await response.json();
      
      if (!response.ok) {
        console.error('PayPal subscription error:', subscription);
        return res.status(400).json({ error: 'Failed to create subscription' });
      }

      res.json(subscription);
    } catch (error) {
      console.error('Create subscription error:', error);
      res.status(500).json({ error: 'Failed to create subscription' });
    }
  });

  // PayPal subscription success
  app.get("/api/paypal/subscription/success", async (req, res) => {
    const { subscription_id, ba_token } = req.query;
    
    try {
      if (!subscription_id) {
        return res.redirect("/register?error=payment_cancelled");
      }

      // Verify subscription status with PayPal
      const response = await fetch(`https://api-m.paypal.com/v1/billing/subscriptions/${subscription_id}`, {
        headers: {
          'Authorization': `Bearer ${await getPayPalAccessToken()}`,
          'Accept': 'application/json'
        }
      });

      const subscription = await response.json();
      
      if (subscription.status === 'ACTIVE') {
        // Store subscription info and redirect to success
        res.redirect(`/payment-success?subscription_id=${subscription_id}&welcome=true`);
      } else {
        res.redirect("/register?error=subscription_pending");
      }
    } catch (error) {
      console.error("PayPal subscription success handler error:", error);
      res.redirect("/register?error=payment_error");
    }
  });

  // Helper function to get PayPal access token
  async function getPayPalAccessToken() {
    const credentials = Buffer.from(`${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`).toString('base64');
    
    const response = await fetch('https://api-m.paypal.com/v1/oauth2/token', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: 'grant_type=client_credentials'
    });

    const data = await response.json();
    return data.access_token;
  }

  // PayPal return URLs
  app.get("/api/paypal/success", async (req, res) => {
    // Redirect old format to new subscription flow
    res.redirect("/register?error=please_retry");
  });

  app.get("/api/paypal/cancel", async (req, res) => {
    res.redirect("/register?error=payment_cancelled");
  });

  // User search and suggestions API
  app.get("/api/users/search", authenticateToken, async (req, res) => {
    try {
      if (!req.user) return res.sendStatus(401);
      
      const { q } = req.query;
      if (!q || typeof q !== 'string' || q.length < 2) {
        return res.json([]);
      }
      
      const users = await storage.searchUsers(q.toLowerCase(), req.user.id);
      res.json(users);
    } catch (error) {
      console.error("User search error:", error);
      res.status(500).json({ error: "Failed to search users" });
    }
  });

  app.get("/api/users/suggested", authenticateToken, async (req, res) => {
    try {
      if (!req.user) return res.sendStatus(401);
      
      const users = await storage.getSuggestedUsers(req.user.id);
      res.json(users);
    } catch (error) {
      console.error("Get suggested users error:", error);
      res.status(500).json({ error: "Failed to get suggested users" });
    }
  });

  app.post("/api/users/:userId/follow", authenticateToken, async (req, res) => {
    try {
      if (!req.user) return res.sendStatus(401);
      
      const { userId } = req.params;
      const result = await storage.followUser(req.user.id, userId);
      
      if (result) {
        res.json({ success: true });
      } else {
        res.status(400).json({ error: "Unable to follow user" });
      }
    } catch (error) {
      console.error("Follow user error:", error);
      res.status(500).json({ error: "Failed to follow user" });
    }
  });

  // Messages API - Real functional messaging
  app.get("/api/messages/conversations", authenticateToken, async (req, res) => {
    try {
      if (!req.user) return res.sendStatus(401);
      const conversations = await storage.getConversations(req.user.id);
      res.json(conversations);
    } catch (error) {
      console.error("Get conversations error:", error);
      res.status(500).json({ error: "Failed to get conversations" });
    }
  });

  app.post("/api/messages", authenticateToken, async (req, res) => {
    try {
      if (!req.user) return res.sendStatus(401);
      
      const { threadId, body, kind = 'text', media = [] } = req.body;
      
      // Create the message
      const message = await storage.createMessage({
        threadId,
        senderId: req.user.id,
        recipientId: threadId.replace(req.user.id, '').replace('_', ''),
        body,
        media,
        kind
      });
      
      res.json(message);
    } catch (error) {
      console.error("Send message error:", error);
      res.status(500).json({ error: "Failed to send message" });
    }
  });

  app.get("/api/messages/:threadId", authenticateToken, async (req, res) => {
    try {
      if (!req.user) return res.sendStatus(401);
      const { threadId } = req.params;
      const { limit = 50, offset = 0 } = req.query;
      
      // Verify user is part of this thread
      if (!threadId.includes(req.user.id)) {
        return res.status(403).json({ error: "Access denied" });
      }

      const messages = await storage.getMessagesByThread(
        threadId, 
        parseInt(limit as string), 
        parseInt(offset as string)
      );
      res.json(messages);
    } catch (error) {
      console.error("Get messages error:", error);
      res.status(500).json({ error: "Failed to get messages" });
    }
  });

  // Daily Vibes API
  app.get("/api/daily-vibes", authenticateToken, async (req, res) => {
    try {
      const { creatorId, limit = 20 } = req.query;
      const vibes = await storage.getDailyVibes(
        creatorId as string, 
        parseInt(limit as string)
      );
      res.json(vibes);
    } catch (error) {
      console.error("Get daily vibes error:", error);
      res.status(500).json({ error: "Failed to get daily vibes" });
    }
  });

  app.post("/api/daily-vibes", authenticateToken, async (req, res) => {
    try {
      if (!req.user) return res.sendStatus(401);
      const vibeData = insertDailyVibeSchema.parse({
        ...req.body,
        creatorId: req.user.id,
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 hours
      });

      const vibe = await storage.createDailyVibe(vibeData);
      res.status(201).json(vibe);
    } catch (error) {
      console.error("Create daily vibe error:", error);
      res.status(500).json({ error: "Failed to create daily vibe" });
    }
  });

  app.post("/api/daily-vibes/:id/view", authenticateToken, async (req, res) => {
    try {
      if (!req.user) return res.sendStatus(401);
      const { id } = req.params;
      const vibe = await storage.getDailyVibe(id);
      
      if (!vibe) {
        return res.status(404).json({ error: "Vibe not found" });
      }

      // Add viewer if not already present
      const viewers = vibe.viewers || [];
      if (!viewers.includes(req.user.id)) {
        const updatedViewers = [...viewers, req.user.id];
        await storage.updateDailyVibe(id, { viewers: updatedViewers });
      }

      res.json({ success: true });
    } catch (error) {
      console.error("View daily vibe error:", error);
      res.status(500).json({ error: "Failed to record view" });
    }
  });

  // Posts API
  app.get("/api/posts", authenticateToken, async (req, res) => {
    try {
      const { creatorId, limit = 20, offset = 0 } = req.query;
      const posts = await storage.getPosts(
        creatorId as string,
        parseInt(limit as string),
        parseInt(offset as string)
      );
      res.json(posts);
    } catch (error) {
      console.error("Get posts error:", error);
      res.status(500).json({ error: "Failed to get posts" });
    }
  });

  app.post("/api/posts", authenticateToken, async (req, res) => {
    try {
      if (!req.user) return res.sendStatus(401);
      
      console.log("Creating post with data:", req.body);
      
      const postData = {
        title: req.body.title || "",
        body: req.body.body,
        visibility: req.body.visibility || "public",
        media: req.body.media || [],
        status: "live",
        creatorId: req.user.id
      };

      const post = await storage.createPost(postData);
      console.log("Post created successfully:", post);
      res.status(201).json(post);
    } catch (error) {
      console.error("Create post error:", error);
      res.status(500).json({ error: "Failed to create post", details: error.message });
    }
  });

  // Creator Profile API
  app.get("/api/creator-profile", authenticateToken, async (req, res) => {
    try {
      if (!req.user) return res.sendStatus(401);
      const profile = await storage.getCreatorProfileByUserId(req.user.id);
      if (!profile) {
        return res.status(404).json({ error: "Creator profile not found" });
      }
      res.json(profile);
    } catch (error) {
      console.error("Get creator profile error:", error);
      res.status(500).json({ error: "Failed to get creator profile" });
    }
  });

  app.post("/api/creator-profile", authenticateToken, requireCreator, async (req, res) => {
    try {
      if (!req.user) return res.sendStatus(401);
      const existing = await storage.getCreatorProfileByUserId(req.user.id);
      if (existing) {
        return res.status(400).json({ error: "Creator profile already exists" });
      }

      const profileData = {
        userId: req.user.id,
        handle: req.body.handle,
        displayName: req.body.displayName,
        bio: req.body.bio,
        banner: req.body.banner,
        premiumPriceGBP: req.body.premiumPriceGBP,
        links: req.body.links || []
      };

      const profile = await storage.createCreatorProfile(profileData);
      res.status(201).json(profile);
    } catch (error) {
      console.error("Create creator profile error:", error);
      res.status(500).json({ error: "Failed to create creator profile" });
    }
  });

  // Creator Dashboard API
  app.get("/api/creator/stats", authenticateToken, requireCreator, async (req, res) => {
    try {
      if (!req.user) return res.sendStatus(401);
      const profile = await storage.getCreatorProfileByUserId(req.user.id);
      if (!profile) {
        return res.status(404).json({ error: "Creator profile not found" });
      }

      const balance = await storage.getCreatorBalance(profile.id);
      const transactions = await storage.getTransactions(undefined, profile.id);
      const posts = await storage.getPosts(req.user.id);

      // Calculate earnings
      const monthlyEarnings = transactions
        .filter(t => {
          const oneMonthAgo = new Date();
          oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
          return t.occurredAt && t.occurredAt >= oneMonthAgo && t.type !== 'PAYOUT';
        })
        .reduce((sum, t) => sum + parseFloat(t.netToCreatorGBP || "0"), 0);

      const counts = profile.counts || { premiumFans: 0, followers: 0 };
      res.json({
        profile,
        balance,
        stats: {
          monthlyEarnings: monthlyEarnings.toFixed(2),
          premiumSubscribers: counts.premiumFans,
          totalFollowers: counts.followers,
          totalPosts: posts.length,
          engagementRate: "8.7" // Mock value
        },
        recentTransactions: transactions.slice(0, 10)
      });
    } catch (error) {
      console.error("Get creator stats error:", error);
      res.status(500).json({ error: "Failed to get creator stats" });
    }
  });

  // Payout API
  app.post("/api/creator/payout", authenticateToken, requireCreator, async (req, res) => {
    try {
      if (!req.user) return res.sendStatus(401);
      const { paypalEmail, amount } = req.body;
      
      const profile = await storage.getCreatorProfileByUserId(req.user.id);
      if (!profile) {
        return res.status(404).json({ error: "Creator profile not found" });
      }

      const balance = await storage.getCreatorBalance(profile.id);
      if (!balance || !balance.availableGBP || parseFloat(balance.availableGBP) < parseFloat(amount)) {
        return res.status(400).json({ error: "Insufficient balance" });
      }

      const settings = await storage.getSettings();
      if (!settings.payoutThresholdGBP || parseFloat(amount) < parseFloat(settings.payoutThresholdGBP)) {
        return res.status(400).json({ 
          error: `Minimum payout amount is £${settings.payoutThresholdGBP || "10"}` 
        });
      }

      const payout = await storage.createPayout({
        creatorId: profile.id,
        amountGBP: amount,
        paypalEmail,
        status: "pending",
        paypalBatchId: null,
        settledAt: null,
        failureReason: null
      });

      // Update balance
      const newAvailable = (parseFloat(balance.availableGBP || "0") - parseFloat(amount)).toFixed(2);
      await storage.updateCreatorBalance(profile.id, { 
        availableGBP: newAvailable 
      });

      res.status(201).json(payout);
    } catch (error) {
      console.error("Request payout error:", error);
      res.status(500).json({ error: "Failed to request payout" });
    }
  });

  // Reports API
  app.post("/api/reports", authenticateToken, async (req, res) => {
    try {
      if (!req.user) return res.sendStatus(401);
      const reportData = insertReportSchema.parse({
        ...req.body,
        reporterId: req.user.id
      });

      const report = await storage.createReport(reportData);
      res.status(201).json(report);
    } catch (error) {
      console.error("Create report error:", error);
      res.status(500).json({ error: "Failed to create report" });
    }
  });

  // Call logging API
  app.post("/api/calls", authenticateToken, async (req, res) => {
    try {
      if (!req.user) return res.sendStatus(401);
      const { calleeId, type } = req.body;
      
      const callLog = await storage.createCallLog({
        callerId: req.user.id,
        calleeId,
        type,
        status: "missed",
        endedAt: null
      });

      res.status(201).json(callLog);
    } catch (error) {
      console.error("Create call log error:", error);
      res.status(500).json({ error: "Failed to log call" });
    }
  });

  // Admin API
  app.get("/api/admin/stats", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const users = await storage.getUser(""); // This is just for count - in real DB you'd have a count method
      const transactions = await storage.getTransactions();
      const reports = await storage.getReports("pending");
      
      // Mock stats for demo
      res.json({
        totalUsers: 24847,
        monthlyRevenue: 47329,
        activeCreators: 1247,
        pendingReports: reports.length
      });
    } catch (error) {
      console.error("Get admin stats error:", error);
      res.status(500).json({ error: "Failed to get admin stats" });
    }
  });

  app.get("/api/admin/reports", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { status = "pending" } = req.query;
      const reports = await storage.getReports(status as string);
      res.json(reports);
    } catch (error) {
      console.error("Get reports error:", error);
      res.status(500).json({ error: "Failed to get reports" });
    }
  });

  app.patch("/api/admin/reports/:id", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const { status, action } = req.body;
      
      const report = await storage.updateReport(id, { status });
      if (!report) {
        return res.status(404).json({ error: "Report not found" });
      }

      res.json(report);
    } catch (error) {
      console.error("Update report error:", error);
      res.status(500).json({ error: "Failed to update report" });
    }
  });

  app.get("/api/admin/settings", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const settings = await storage.getSettings();
      res.json(settings);
    } catch (error) {
      console.error("Get settings error:", error);
      res.status(500).json({ error: "Failed to get settings" });
    }
  });

  app.patch("/api/admin/settings", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const settings = await storage.updateSettings(req.body);
      res.json(settings);
    } catch (error) {
      console.error("Update settings error:", error);
      res.status(500).json({ error: "Failed to update settings" });
    }
  });

  // WebSocket token endpoint
  app.get("/api/ws-token", authenticateToken, (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const token = jwt.sign({ userId: req.user.id }, process.env.JWT_SECRET!, { expiresIn: '24h' });
    res.json({ token });
  });

  // Cleanup expired vibes periodically
  setInterval(async () => {
    try {
      await storage.deleteExpiredVibes();
    } catch (error) {
      console.error("Cleanup expired vibes error:", error);
    }
  }, 60 * 60 * 1000); // Every hour

  const httpServer = createServer(app);
  
  // Setup WebSocket
  setupWebSocket(httpServer);

  return httpServer;
}
