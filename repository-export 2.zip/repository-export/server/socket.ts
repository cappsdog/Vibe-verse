import { WebSocketServer, WebSocket } from "ws";
import { Server } from "http";
import jwt from "jsonwebtoken";
import { storage } from "./storage";

interface AuthenticatedWebSocket extends WebSocket {
  userId?: string;
  isAlive?: boolean;
}

interface SocketMessage {
  type: string;
  payload: any;
}

export function setupWebSocket(server: Server) {
  const wss = new WebSocketServer({ 
    server, 
    path: '/ws',
    verifyClient: async (info) => {
      try {
        const url = new URL(info.req.url!, `http://${info.req.headers.host}`);
        const token = url.searchParams.get('token');
        
        if (!token) return false;
        
        const decoded = jwt.verify(token, process.env.JWT_SECRET!) as { userId: string };
        const user = await storage.getUser(decoded.userId);
        
        return !!user;
      } catch (error) {
        return false;
      }
    }
  });

  const clients = new Map<string, AuthenticatedWebSocket>();

  wss.on('connection', async (ws: AuthenticatedWebSocket, req) => {
    try {
      const url = new URL(req.url!, `http://${req.headers.host}`);
      const token = url.searchParams.get('token');
      
      if (!token) {
        ws.close(1008, 'No token provided');
        return;
      }

      const decoded = jwt.verify(token, process.env.JWT_SECRET!) as { userId: string };
      ws.userId = decoded.userId;
      ws.isAlive = true;
      
      clients.set(decoded.userId, ws);
      
      // Send online status to contacts
      broadcastPresence(decoded.userId, 'online');

      ws.on('pong', () => {
        ws.isAlive = true;
      });

      ws.on('message', async (data) => {
        try {
          const message: SocketMessage = JSON.parse(data.toString());
          await handleMessage(ws, message);
        } catch (error) {
          console.error('WebSocket message error:', error);
          ws.send(JSON.stringify({ type: 'error', payload: { message: 'Invalid message format' } }));
        }
      });

      ws.on('close', () => {
        if (ws.userId) {
          clients.delete(ws.userId);
          broadcastPresence(ws.userId, 'offline');
        }
      });

      ws.send(JSON.stringify({ type: 'connected', payload: { userId: decoded.userId } }));

    } catch (error) {
      console.error('WebSocket connection error:', error);
      ws.close(1008, 'Authentication failed');
    }
  });

  // Heartbeat to keep connections alive
  const interval = setInterval(() => {
    wss.clients.forEach((ws: AuthenticatedWebSocket) => {
      if (!ws.isAlive) {
        return ws.terminate();
      }
      
      ws.isAlive = false;
      ws.ping();
    });
  }, 30000);

  wss.on('close', () => {
    clearInterval(interval);
  });

  async function handleMessage(ws: AuthenticatedWebSocket, message: SocketMessage) {
    const { type, payload } = message;

    switch (type) {
      case 'send_message':
        await handleSendMessage(ws, payload);
        break;
        
      case 'typing_start':
        handleTypingIndicator(ws, payload, true);
        break;
        
      case 'typing_stop':
        handleTypingIndicator(ws, payload, false);
        break;
        
      case 'read_message':
        await handleReadMessage(ws, payload);
        break;
        
      case 'call_offer':
        handleCallSignaling(ws, payload, 'call_offer');
        break;
        
      case 'call_answer':
        handleCallSignaling(ws, payload, 'call_answer');
        break;
        
      case 'call_candidate':
        handleCallSignaling(ws, payload, 'call_candidate');
        break;
        
      case 'call_end':
        await handleCallEnd(ws, payload);
        break;
        
      case 'call_decline':
        handleCallSignaling(ws, payload, 'call_decline');
        break;

      default:
        ws.send(JSON.stringify({ type: 'error', payload: { message: 'Unknown message type' } }));
    }
  }

  async function handleSendMessage(ws: AuthenticatedWebSocket, payload: any) {
    try {
      const { recipientId, body, media, kind } = payload;
      
      if (!ws.userId) return;

      // Generate thread ID (consistent ordering)
      const threadId = [ws.userId, recipientId].sort().join('-');
      
      const message = await storage.createMessage({
        threadId,
        senderId: ws.userId,
        recipientId,
        body,
        media: media || [],
        kind: kind || 'text'
      });

      // Send to recipient if online
      const recipientWs = clients.get(recipientId);
      if (recipientWs && recipientWs.readyState === WebSocket.OPEN) {
        recipientWs.send(JSON.stringify({
          type: 'new_message',
          payload: message
        }));
      }

      // Confirm to sender
      ws.send(JSON.stringify({
        type: 'message_sent',
        payload: message
      }));

    } catch (error) {
      console.error('Send message error:', error);
      ws.send(JSON.stringify({ 
        type: 'error', 
        payload: { message: 'Failed to send message' } 
      }));
    }
  }

  function handleTypingIndicator(ws: AuthenticatedWebSocket, payload: any, isTyping: boolean) {
    const { recipientId } = payload;
    
    if (!ws.userId) return;

    const recipientWs = clients.get(recipientId);
    if (recipientWs && recipientWs.readyState === WebSocket.OPEN) {
      recipientWs.send(JSON.stringify({
        type: isTyping ? 'user_typing' : 'user_stopped_typing',
        payload: { userId: ws.userId }
      }));
    }
  }

  async function handleReadMessage(ws: AuthenticatedWebSocket, payload: any) {
    try {
      const { messageId } = payload;
      
      if (!ws.userId) return;

      const message = await storage.getMessage(messageId);
      if (!message) return;

      // Add read receipt
      const readAt = message.readAt || [];
      if (!readAt.some(read => read.userId === ws.userId)) {
        readAt.push({ userId: ws.userId, readAt: new Date() });
        await storage.updateMessage(messageId, { readAt });
      }

      // Notify sender
      const senderWs = clients.get(message.senderId);
      if (senderWs && senderWs.readyState === WebSocket.OPEN) {
        senderWs.send(JSON.stringify({
          type: 'message_read',
          payload: { messageId, readBy: ws.userId }
        }));
      }

    } catch (error) {
      console.error('Read message error:', error);
    }
  }

  function handleCallSignaling(ws: AuthenticatedWebSocket, payload: any, signalType: string) {
    const { targetUserId } = payload;
    
    if (!ws.userId) return;

    const targetWs = clients.get(targetUserId);
    if (targetWs && targetWs.readyState === WebSocket.OPEN) {
      targetWs.send(JSON.stringify({
        type: signalType,
        payload: { ...payload, fromUserId: ws.userId }
      }));
    }
  }

  async function handleCallEnd(ws: AuthenticatedWebSocket, payload: any) {
    try {
      const { targetUserId, callId, duration } = payload;
      
      if (!ws.userId) return;

      // Update call log
      if (callId) {
        await storage.updateCallLog(callId, {
          endedAt: new Date(),
          status: 'connected',
          durationSec: duration || 0
        });
      }

      // Notify other participant
      const targetWs = clients.get(targetUserId);
      if (targetWs && targetWs.readyState === WebSocket.OPEN) {
        targetWs.send(JSON.stringify({
          type: 'call_ended',
          payload: { callId, endedBy: ws.userId }
        }));
      }

    } catch (error) {
      console.error('Call end error:', error);
    }
  }

  function broadcastPresence(userId: string, status: 'online' | 'offline') {
    // This is a simplified version - in production you'd want to only notify contacts/friends
    clients.forEach((clientWs, clientId) => {
      if (clientId !== userId && clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(JSON.stringify({
          type: 'user_presence',
          payload: { userId, status }
        }));
      }
    });
  }

  return wss;
}
