import { type User, type InsertUser, type CreatorProfile, type InsertCreatorProfile, type Message, type InsertMessage, type DailyVibe, type InsertDailyVibe, type Post, type InsertPost, type Transaction, type InsertTransaction, type Report, type InsertReport, type CallLog, type CreatorBalance, type Payout, type PlatformSettings } from "@shared/schema";
import { randomUUID } from "crypto";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User management
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;

  // Creator profiles
  getCreatorProfile(id: string): Promise<CreatorProfile | undefined>;
  getCreatorProfileByUserId(userId: string): Promise<CreatorProfile | undefined>;
  getCreatorProfileByHandle(handle: string): Promise<CreatorProfile | undefined>;
  createCreatorProfile(profile: InsertCreatorProfile): Promise<CreatorProfile>;
  updateCreatorProfile(id: string, updates: Partial<CreatorProfile>): Promise<CreatorProfile | undefined>;

  // Messages
  getMessage(id: string): Promise<Message | undefined>;
  getMessagesByThread(threadId: string, limit?: number, offset?: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  updateMessage(id: string, updates: Partial<Message>): Promise<Message | undefined>;
  getConversations(userId: string): Promise<Array<{ threadId: string; lastMessage: Message; unreadCount: number }>>;

  // Daily Vibes
  getDailyVibe(id: string): Promise<DailyVibe | undefined>;
  getDailyVibes(creatorId?: string, limit?: number): Promise<DailyVibe[]>;
  createDailyVibe(vibe: InsertDailyVibe): Promise<DailyVibe>;
  updateDailyVibe(id: string, updates: Partial<DailyVibe>): Promise<DailyVibe | undefined>;
  deleteExpiredVibes(): Promise<void>;

  // Posts
  getPost(id: string): Promise<Post | undefined>;
  getPosts(creatorId?: string, limit?: number, offset?: number): Promise<Post[]>;
  createPost(post: InsertPost): Promise<Post>;
  updatePost(id: string, updates: Partial<Post>): Promise<Post | undefined>;

  // Transactions
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getTransactions(userId?: string, creatorId?: string, type?: string): Promise<Transaction[]>;

  // Reports
  createReport(report: InsertReport): Promise<Report>;
  getReports(status?: string): Promise<Report[]>;
  updateReport(id: string, updates: Partial<Report>): Promise<Report | undefined>;

  // Creator balances
  getCreatorBalance(creatorId: string): Promise<CreatorBalance | undefined>;
  updateCreatorBalance(creatorId: string, updates: Partial<CreatorBalance>): Promise<CreatorBalance>;

  // Payouts
  createPayout(payout: Omit<Payout, 'id' | 'initiatedAt'>): Promise<Payout>;
  getPayouts(creatorId?: string): Promise<Payout[]>;
  updatePayout(id: string, updates: Partial<Payout>): Promise<Payout | undefined>;

  // Call logs
  createCallLog(log: Omit<CallLog, 'id' | 'startedAt' | 'durationSec'>): Promise<CallLog>;
  updateCallLog(id: string, updates: Partial<CallLog>): Promise<CallLog | undefined>;

  // Settings
  getSettings(): Promise<PlatformSettings>;
  updateSettings(updates: Partial<PlatformSettings>): Promise<PlatformSettings>;

  sessionStore: any;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private creatorProfiles: Map<string, CreatorProfile>;
  private messages: Map<string, Message>;
  private dailyVibes: Map<string, DailyVibe>;
  private posts: Map<string, Post>;
  private transactions: Map<string, Transaction>;
  private reports: Map<string, Report>;
  private creatorBalances: Map<string, CreatorBalance>;
  private payouts: Map<string, Payout>;
  private callLogs: Map<string, CallLog>;
  private settings: PlatformSettings;
  public sessionStore: any;

  constructor() {
    this.users = new Map();
    this.creatorProfiles = new Map();
    this.messages = new Map();
    this.dailyVibes = new Map();
    this.posts = new Map();
    this.transactions = new Map();
    this.reports = new Map();
    this.creatorBalances = new Map();
    this.payouts = new Map();
    this.callLogs = new Map();
    this.settings = {
      id: "platform_settings",
      platformFeePercent: "40.00",
      payoutThresholdGBP: "50.00",
      trialDays: 7,
      maxStorySec: 60,
      updatedAt: new Date(),
    };
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  // User management
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      subscription: insertUser.subscription || { plan: null, status: "expired" },
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    const updated = { ...user, ...updates };
    this.users.set(id, updated);
    return updated;
  }

  // User search and follow functionality
  async searchUsers(query: string, currentUserId: string): Promise<any[]> {
    const users = Array.from(this.users.values())
      .filter(user => 
        user.id !== currentUserId && 
        user.username.toLowerCase().includes(query)
      )
      .map(user => ({
        id: user.id,
        username: user.username,
        email: user.email,
        avatar: user.avatar,
        subscription: user.subscription,
        isCreator: user.subscription?.plan === 'creator',
        followerCount: Math.floor(Math.random() * 1000), // Placeholder for demo
        postCount: Math.floor(Math.random() * 50) // Placeholder for demo
      }))
      .slice(0, 10); // Limit to 10 results
    
    return users;
  }

  async getSuggestedUsers(currentUserId: string): Promise<any[]> {
    const users = Array.from(this.users.values())
      .filter(user => user.id !== currentUserId)
      .map(user => ({
        id: user.id,
        username: user.username,
        email: user.email,
        avatar: user.avatar,
        subscription: user.subscription,
        isCreator: user.subscription?.plan === 'creator',
        followerCount: Math.floor(Math.random() * 1000),
        postCount: Math.floor(Math.random() * 50)
      }))
      .slice(0, 5); // Suggest 5 users
    
    return users;
  }

  async followUser(followerId: string, targetUserId: string): Promise<boolean> {
    // For now, just return true as we don't have a follows table
    // In a real implementation, you'd store the follow relationship
    return true;
  }

  // Creator profiles
  async getCreatorProfile(id: string): Promise<CreatorProfile | undefined> {
    return this.creatorProfiles.get(id);
  }

  async getCreatorProfileByUserId(userId: string): Promise<CreatorProfile | undefined> {
    return Array.from(this.creatorProfiles.values()).find(profile => profile.userId === userId);
  }

  async getCreatorProfileByHandle(handle: string): Promise<CreatorProfile | undefined> {
    return Array.from(this.creatorProfiles.values()).find(profile => profile.handle === handle);
  }

  async createCreatorProfile(insertProfile: InsertCreatorProfile): Promise<CreatorProfile> {
    const id = randomUUID();
    const profile: CreatorProfile = {
      ...insertProfile,
      id,
      counts: { followers: 0, premiumFans: 0, posts: 0 },
      createdAt: new Date(),
    };
    this.creatorProfiles.set(id, profile);
    return profile;
  }

  async updateCreatorProfile(id: string, updates: Partial<CreatorProfile>): Promise<CreatorProfile | undefined> {
    const profile = this.creatorProfiles.get(id);
    if (!profile) return undefined;
    const updated = { ...profile, ...updates };
    this.creatorProfiles.set(id, updated);
    return updated;
  }

  // Messages
  async getMessage(id: string): Promise<Message | undefined> {
    return this.messages.get(id);
  }

  async getMessagesByThread(threadId: string, limit = 50, offset = 0): Promise<Message[]> {
    const messages = Array.from(this.messages.values())
      .filter(msg => msg.threadId === threadId)
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime())
      .slice(offset, offset + limit);
    return messages;
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = randomUUID();
    const message: Message = {
      ...insertMessage,
      id,
      readAt: [],
      reactions: [],
      createdAt: new Date(),
    };
    this.messages.set(id, message);
    return message;
  }

  async updateMessage(id: string, updates: Partial<Message>): Promise<Message | undefined> {
    const message = this.messages.get(id);
    if (!message) return undefined;
    const updated = { ...message, ...updates };
    this.messages.set(id, updated);
    return updated;
  }

  async getConversations(userId: string): Promise<Array<{ threadId: string; lastMessage: Message; unreadCount: number }>> {
    const userMessages = Array.from(this.messages.values())
      .filter(msg => msg.senderId === userId || msg.recipientId === userId);
    
    const threadMap = new Map<string, Message>();
    userMessages.forEach(msg => {
      const existing = threadMap.get(msg.threadId);
      if (!existing || msg.createdAt! > existing.createdAt!) {
        threadMap.set(msg.threadId, msg);
      }
    });

    const conversations = Array.from(threadMap.entries()).map(([threadId, lastMessage]) => {
      const unreadCount = userMessages.filter(msg => 
        msg.threadId === threadId && 
        msg.senderId !== userId && 
        !msg.readAt.some(read => read.userId === userId)
      ).length;
      
      return { threadId, lastMessage, unreadCount };
    });

    return conversations.sort((a, b) => b.lastMessage.createdAt!.getTime() - a.lastMessage.createdAt!.getTime());
  }

  // Daily Vibes
  async getDailyVibe(id: string): Promise<DailyVibe | undefined> {
    const vibe = this.dailyVibes.get(id);
    if (vibe && vibe.expiresAt < new Date()) {
      this.dailyVibes.delete(id);
      return undefined;
    }
    return vibe;
  }

  async getDailyVibes(creatorId?: string, limit = 20): Promise<DailyVibe[]> {
    let vibes = Array.from(this.dailyVibes.values())
      .filter(vibe => vibe.expiresAt > new Date());
    
    if (creatorId) {
      vibes = vibes.filter(vibe => vibe.creatorId === creatorId);
    }
    
    return vibes
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime())
      .slice(0, limit);
  }

  async createDailyVibe(insertVibe: InsertDailyVibe): Promise<DailyVibe> {
    const id = randomUUID();
    const vibe: DailyVibe = {
      ...insertVibe,
      id,
      viewers: [],
      createdAt: new Date(),
    };
    this.dailyVibes.set(id, vibe);
    return vibe;
  }

  async updateDailyVibe(id: string, updates: Partial<DailyVibe>): Promise<DailyVibe | undefined> {
    const vibe = this.dailyVibes.get(id);
    if (!vibe) return undefined;
    const updated = { ...vibe, ...updates };
    this.dailyVibes.set(id, updated);
    return updated;
  }

  async deleteExpiredVibes(): Promise<void> {
    const now = new Date();
    for (const [id, vibe] of this.dailyVibes.entries()) {
      if (vibe.expiresAt < now) {
        this.dailyVibes.delete(id);
      }
    }
  }

  // Posts
  async getPost(id: string): Promise<Post | undefined> {
    return this.posts.get(id);
  }

  async getPosts(creatorId?: string, limit = 20, offset = 0): Promise<Post[]> {
    let posts = Array.from(this.posts.values())
      .filter(post => post.status === "live");
    
    if (creatorId) {
      posts = posts.filter(post => post.creatorId === creatorId);
    }
    
    return posts
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime())
      .slice(offset, offset + limit);
  }

  async createPost(insertPost: InsertPost): Promise<Post> {
    const id = randomUUID();
    const post: Post = {
      ...insertPost,
      id,
      safety: { checked: false, flagged: false },
      stats: { likes: 0, comments: 0, shares: 0 },
      createdAt: new Date(),
    };
    this.posts.set(id, post);
    return post;
  }

  async updatePost(id: string, updates: Partial<Post>): Promise<Post | undefined> {
    const post = this.posts.get(id);
    if (!post) return undefined;
    const updated = { ...post, ...updates };
    this.posts.set(id, updated);
    return updated;
  }

  // Transactions
  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = randomUUID();
    const transaction: Transaction = {
      ...insertTransaction,
      id,
      occurredAt: new Date(),
    };
    this.transactions.set(id, transaction);
    return transaction;
  }

  async getTransactions(userId?: string, creatorId?: string, type?: string): Promise<Transaction[]> {
    let transactions = Array.from(this.transactions.values());
    
    if (userId) {
      transactions = transactions.filter(t => t.userId === userId);
    }
    if (creatorId) {
      transactions = transactions.filter(t => t.creatorId === creatorId);
    }
    if (type) {
      transactions = transactions.filter(t => t.type === type);
    }
    
    return transactions.sort((a, b) => b.occurredAt!.getTime() - a.occurredAt!.getTime());
  }

  // Reports
  async createReport(insertReport: InsertReport): Promise<Report> {
    const id = randomUUID();
    const report: Report = {
      ...insertReport,
      id,
      createdAt: new Date(),
    };
    this.reports.set(id, report);
    return report;
  }

  async getReports(status?: string): Promise<Report[]> {
    let reports = Array.from(this.reports.values());
    
    if (status) {
      reports = reports.filter(r => r.status === status);
    }
    
    return reports.sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime());
  }

  async updateReport(id: string, updates: Partial<Report>): Promise<Report | undefined> {
    const report = this.reports.get(id);
    if (!report) return undefined;
    const updated = { ...report, ...updates };
    this.reports.set(id, updated);
    return updated;
  }

  // Creator balances
  async getCreatorBalance(creatorId: string): Promise<CreatorBalance | undefined> {
    return Array.from(this.creatorBalances.values()).find(b => b.creatorId === creatorId);
  }

  async updateCreatorBalance(creatorId: string, updates: Partial<CreatorBalance>): Promise<CreatorBalance> {
    const existing = await this.getCreatorBalance(creatorId);
    if (existing) {
      const updated = { ...existing, ...updates, lastUpdated: new Date() };
      this.creatorBalances.set(existing.id, updated);
      return updated;
    } else {
      const id = randomUUID();
      const balance: CreatorBalance = {
        id,
        creatorId,
        availableGBP: "0",
        pendingGBP: "0",
        lastUpdated: new Date(),
        ...updates,
      };
      this.creatorBalances.set(id, balance);
      return balance;
    }
  }

  // Messages - Real messaging functionality
  async getConversations(userId: string): Promise<any[]> {
    const userMessages = Array.from(this.messages.values())
      .filter(msg => msg.senderId === userId || msg.recipientId === userId);
    
    const threadGroups = new Map<string, any[]>();
    
    userMessages.forEach(msg => {
      if (!threadGroups.has(msg.threadId)) {
        threadGroups.set(msg.threadId, []);
      }
      threadGroups.get(msg.threadId)!.push(msg);
    });
    
    const conversations = Array.from(threadGroups.entries()).map(([threadId, messages]) => {
      const sortedMessages = messages.sort((a, b) => 
        new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
      );
      
      return {
        threadId,
        lastMessage: sortedMessages[0],
        unreadCount: sortedMessages.filter(msg => 
          msg.senderId !== userId && 
          !msg.readAt.some(r => r.userId === userId)
        ).length
      };
    });
    
    return conversations.sort((a, b) => 
      new Date(b.lastMessage.createdAt).getTime() - new Date(a.lastMessage.createdAt).getTime()
    );
  }

  async getMessagesByThread(threadId: string, limit = 50, offset = 0): Promise<Message[]> {
    const messages = Array.from(this.messages.values())
      .filter(msg => msg.threadId === threadId)
      .sort((a, b) => new Date(a.createdAt!).getTime() - new Date(b.createdAt!).getTime());
    
    return messages.slice(offset, offset + limit);
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = randomUUID();
    const message: Message = {
      ...insertMessage,
      id,
      createdAt: new Date(),
    };
    this.messages.set(id, message);
    return message;
  }

  // Payouts
  async createPayout(insertPayout: Omit<Payout, 'id' | 'initiatedAt'>): Promise<Payout> {
    const id = randomUUID();
    const payout: Payout = {
      ...insertPayout,
      id,
      initiatedAt: new Date(),
    };
    this.payouts.set(id, payout);
    return payout;
  }

  async getPayouts(creatorId?: string): Promise<Payout[]> {
    let payouts = Array.from(this.payouts.values());
    
    if (creatorId) {
      payouts = payouts.filter(p => p.creatorId === creatorId);
    }
    
    return payouts.sort((a, b) => b.initiatedAt!.getTime() - a.initiatedAt!.getTime());
  }

  async updatePayout(id: string, updates: Partial<Payout>): Promise<Payout | undefined> {
    const payout = this.payouts.get(id);
    if (!payout) return undefined;
    const updated = { ...payout, ...updates };
    this.payouts.set(id, updated);
    return updated;
  }

  // Call logs
  async createCallLog(insertLog: Omit<CallLog, 'id' | 'startedAt' | 'durationSec'>): Promise<CallLog> {
    const id = randomUUID();
    const callLog: CallLog = {
      ...insertLog,
      id,
      startedAt: new Date(),
      durationSec: 0,
    };
    this.callLogs.set(id, callLog);
    return callLog;
  }

  async updateCallLog(id: string, updates: Partial<CallLog>): Promise<CallLog | undefined> {
    const callLog = this.callLogs.get(id);
    if (!callLog) return undefined;
    const updated = { ...callLog, ...updates };
    this.callLogs.set(id, updated);
    return updated;
  }

  // Settings
  async getSettings(): Promise<PlatformSettings> {
    return this.settings;
  }

  async updateSettings(updates: Partial<PlatformSettings>): Promise<PlatformSettings> {
    this.settings = { ...this.settings, ...updates, updatedAt: new Date() };
    return this.settings;
  }
}

export const storage = new MemStorage();
