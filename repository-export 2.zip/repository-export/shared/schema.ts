import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, integer, decimal, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("user"), // user, creator, admin
  isCreator: boolean("is_creator").default(false),
  subscription: jsonb("subscription").$type<{
    plan: "free" | "basic" | "creator" | null;
    paypalSubscriptionId?: string;
    status: "active" | "cancelled" | "expired" | "pending";
    currentPeriodEnd?: Date;
  }>().default(sql`'{"plan": "free", "status": "active"}'::jsonb`),
  avatar: text("avatar"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  emailIdx: index("users_email_idx").on(table.email),
  usernameIdx: index("users_username_idx").on(table.username),
}));

export const creatorProfiles = pgTable("creator_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  handle: text("handle").notNull().unique(),
  displayName: text("display_name").notNull(),
  bio: text("bio"),
  banner: text("banner"),
  premiumPriceGBP: decimal("premium_price_gbp", { precision: 10, scale: 2 }),
  paypalPlanId: text("paypal_plan_id"),
  links: jsonb("links").$type<Array<{ title: string; url: string }>>().default(sql`'[]'::jsonb`),
  counts: jsonb("counts").$type<{
    followers: number;
    premiumFans: number;
    posts: number;
  }>().default(sql`'{"followers": 0, "premiumFans": 0, "posts": 0}'::jsonb`),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  userIdx: index("creator_profiles_user_idx").on(table.userId),
  handleIdx: index("creator_profiles_handle_idx").on(table.handle),
}));

export const creatorFanSubs = pgTable("creator_fan_subs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fanId: varchar("fan_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  creatorId: varchar("creator_id").notNull().references(() => creatorProfiles.id, { onDelete: "cascade" }),
  paypalSubscriptionId: text("paypal_subscription_id").notNull(),
  status: text("status").notNull().default("active"), // active, cancelled, expired
  startedAt: timestamp("started_at").defaultNow(),
  renewedAt: timestamp("renewed_at"),
  cancelledAt: timestamp("cancelled_at"),
}, (table) => ({
  fanCreatorIdx: index("creator_fan_subs_fan_creator_idx").on(table.fanId, table.creatorId),
  paypalIdx: index("creator_fan_subs_paypal_idx").on(table.paypalSubscriptionId),
}));

export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  threadId: varchar("thread_id").notNull(),
  senderId: varchar("sender_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  recipientId: varchar("recipient_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  body: text("body"),
  media: jsonb("media").$type<Array<{ type: "image" | "video" | "voice"; url: string; size?: number }>>().default(sql`'[]'::jsonb`),
  kind: text("kind").notNull().default("text"), // text, image, video, voice
  readAt: jsonb("read_at").$type<Array<{ userId: string; readAt: Date }>>().default(sql`'[]'::jsonb`),
  reactions: jsonb("reactions").$type<Array<{ userId: string; emoji: string }>>().default(sql`'[]'::jsonb`),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  threadIdx: index("messages_thread_idx").on(table.threadId),
  senderIdx: index("messages_sender_idx").on(table.senderId),
  recipientIdx: index("messages_recipient_idx").on(table.recipientId),
}));

export const callLogs = pgTable("call_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  callerId: varchar("caller_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  calleeId: varchar("callee_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  type: text("type").notNull(), // audio, video
  startedAt: timestamp("started_at").defaultNow(),
  endedAt: timestamp("ended_at"),
  status: text("status").notNull(), // missed, declined, connected
  durationSec: integer("duration_sec").default(0),
}, (table) => ({
  callerIdx: index("call_logs_caller_idx").on(table.callerId),
  calleeIdx: index("call_logs_callee_idx").on(table.calleeId),
}));

export const dailyVibes = pgTable("daily_vibes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  creatorId: varchar("creator_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  media: jsonb("media").$type<{ type: "image" | "video"; url: string; duration?: number }>().notNull(),
  caption: text("caption"),
  visibility: text("visibility").notNull().default("public"), // public, premium
  viewers: jsonb("viewers").$type<Array<string>>().default(sql`'[]'::jsonb`),
  createdAt: timestamp("created_at").defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
}, (table) => ({
  creatorIdx: index("daily_vibes_creator_idx").on(table.creatorId),
  expiresIdx: index("daily_vibes_expires_idx").on(table.expiresAt),
}));

export const posts = pgTable("posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  creatorId: varchar("creator_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: text("title"),
  body: text("body").notNull(),
  media: jsonb("media").$type<Array<{ type: "image" | "video"; url: string; alt?: string }>>().default(sql`'[]'::jsonb`),
  visibility: text("visibility").notNull().default("public"), // public, premium
  status: text("status").notNull().default("live"), // live, flagged, removed
  safety: jsonb("safety").$type<{
    checked: boolean;
    flagged: boolean;
    reasons?: string[];
  }>().default(sql`'{"checked": false, "flagged": false}'::jsonb`),
  stats: jsonb("stats").$type<{
    likes: number;
    comments: number;
    shares: number;
  }>().default(sql`'{"likes": 0, "comments": 0, "shares": 0}'::jsonb`),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  creatorIdx: index("posts_creator_idx").on(table.creatorId),
  statusIdx: index("posts_status_idx").on(table.status),
  createdIdx: index("posts_created_idx").on(table.createdAt),
}));

export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(), // MEMBERSHIP, FAN_SUB, REFUND, PAYOUT
  grossGBP: decimal("gross_gbp", { precision: 10, scale: 2 }).notNull(),
  feeGBP: decimal("fee_gbp", { precision: 10, scale: 2 }).default("0"),
  platformFeeGBP: decimal("platform_fee_gbp", { precision: 10, scale: 2 }).default("0"),
  netToCreatorGBP: decimal("net_to_creator_gbp", { precision: 10, scale: 2 }).default("0"),
  userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }),
  creatorId: varchar("creator_id").references(() => creatorProfiles.id, { onDelete: "cascade" }),
  paypalIds: jsonb("paypal_ids").$type<{
    orderId?: string;
    paymentId?: string;
    subscriptionId?: string;
  }>().default(sql`'{}'::jsonb`),
  occurredAt: timestamp("occurred_at").defaultNow(),
}, (table) => ({
  typeIdx: index("transactions_type_idx").on(table.type),
  userIdx: index("transactions_user_idx").on(table.userId),
  creatorIdx: index("transactions_creator_idx").on(table.creatorId),
}));

export const creatorBalances = pgTable("creator_balances", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  creatorId: varchar("creator_id").notNull().references(() => creatorProfiles.id, { onDelete: "cascade" }).unique(),
  availableGBP: decimal("available_gbp", { precision: 10, scale: 2 }).default("0"),
  pendingGBP: decimal("pending_gbp", { precision: 10, scale: 2 }).default("0"),
  lastUpdated: timestamp("last_updated").defaultNow(),
}, (table) => ({
  creatorIdx: index("creator_balances_creator_idx").on(table.creatorId),
}));

export const payouts = pgTable("payouts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  creatorId: varchar("creator_id").notNull().references(() => creatorProfiles.id, { onDelete: "cascade" }),
  amountGBP: decimal("amount_gbp", { precision: 10, scale: 2 }).notNull(),
  paypalBatchId: text("paypal_batch_id"),
  paypalEmail: text("paypal_email").notNull(),
  status: text("status").notNull().default("pending"), // pending, processing, completed, failed
  initiatedAt: timestamp("initiated_at").defaultNow(),
  settledAt: timestamp("settled_at"),
  failureReason: text("failure_reason"),
}, (table) => ({
  creatorIdx: index("payouts_creator_idx").on(table.creatorId),
  statusIdx: index("payouts_status_idx").on(table.status),
}));

export const reports = pgTable("reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  reporterId: varchar("reporter_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  targetType: text("target_type").notNull(), // content, message, call, story, user
  targetId: varchar("target_id").notNull(),
  reason: text("reason").notNull(),
  description: text("description"),
  status: text("status").notNull().default("pending"), // pending, reviewed, resolved, dismissed
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  reporterIdx: index("reports_reporter_idx").on(table.reporterId),
  targetIdx: index("reports_target_idx").on(table.targetType, table.targetId),
  statusIdx: index("reports_status_idx").on(table.status),
}));

export const settings = pgTable("settings", {
  id: varchar("id").primaryKey().default("platform_settings"),
  platformFeePercent: decimal("platform_fee_percent", { precision: 5, scale: 2 }).default("40.00"),
  payoutThresholdGBP: decimal("payout_threshold_gbp", { precision: 10, scale: 2 }).default("50.00"),
  trialDays: integer("trial_days").default(7),
  maxStorySec: integer("max_story_sec").default(60),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Schema types
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertCreatorProfileSchema = createInsertSchema(creatorProfiles).omit({ id: true, createdAt: true, counts: true });
export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, createdAt: true, readAt: true, reactions: true });
export const insertDailyVibeSchema = createInsertSchema(dailyVibes).omit({ id: true, createdAt: true, viewers: true });
export const insertPostSchema = createInsertSchema(posts).omit({ id: true, createdAt: true, safety: true, stats: true });
export const insertTransactionSchema = createInsertSchema(transactions).omit({ id: true, occurredAt: true });
export const insertReportSchema = createInsertSchema(reports).omit({ id: true, createdAt: true });

// Inferred types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type CreatorProfile = typeof creatorProfiles.$inferSelect;
export type InsertCreatorProfile = z.infer<typeof insertCreatorProfileSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type DailyVibe = typeof dailyVibes.$inferSelect;
export type InsertDailyVibe = z.infer<typeof insertDailyVibeSchema>;
export type Post = typeof posts.$inferSelect;
export type InsertPost = z.infer<typeof insertPostSchema>;
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Report = typeof reports.$inferSelect;
export type InsertReport = z.infer<typeof insertReportSchema>;
export type CallLog = typeof callLogs.$inferSelect;
export type CreatorBalance = typeof creatorBalances.$inferSelect;
export type Payout = typeof payouts.$inferSelect;
export type PlatformSettings = typeof settings.$inferSelect;
